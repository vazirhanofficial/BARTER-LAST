import React, { useState, useEffect } from 'react';
import { AppScreen, Deal, Product } from './types';
import { storageService } from './services/storageService';
import { BottomNav } from './components/BottomNav';
import { MarketScreen } from './screens/MarketScreen';
import { ChatListScreen } from './screens/ChatListScreen';
import { ChatScreen } from './screens/ChatScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { DealScreen } from './screens/DealScreen';
import { SellerProfileScreen } from './screens/SellerProfileScreen';
import { LanguageProvider } from './contexts/LanguageContext';
import { SplashScreen } from './components/SplashScreen';

const AppContent = () => {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<AppScreen>(AppScreen.MARKET);
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.MARKET);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [selectedSellerId, setSelectedSellerId] = useState<number | null>(null);

  useEffect(() => {
    // Initialize Telegram WebApp
    const tg = (window as any).Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      // Set header color to match app
      if (tg.setHeaderColor) tg.setHeaderColor('#09090b');
      if (tg.setBackgroundColor) tg.setBackgroundColor('#09090b');

      // Sync User Data
      if (tg.initDataUnsafe?.user) {
        storageService.syncWithTelegram(tg.initDataUnsafe.user);
      }
    }
  }, []);

  const handleNavigate = (screen: AppScreen) => {
    setCurrentScreen(screen);
    if ([AppScreen.MARKET, AppScreen.CHAT_LIST, AppScreen.PROFILE].includes(screen)) {
      setActiveTab(screen);
    }
  };

  const handleBuyProduct = (product: Product) => {
    const user = storageService.getUser();
    // 1. Create Deal
    const newDeal: Deal = {
      id: `d_${Date.now()}`,
      productId: product.id,
      sellerId: product.sellerId,
      buyerId: user.id, // Current user ID
      title: product.title,
      price: product.price,
      currency: product.currency,
      status: 'active',
      date: new Date().toISOString()
    };
    storageService.saveDeal(newDeal);
    
    // 2. Create/Update Chat
    const chatPreview = {
      id: `c_${product.sellerId}`,
      partnerId: product.sellerId,
      partnerName: product.sellerName,
      partnerAvatar: product.sellerAvatar,
      lastMessage: `Started deal: ${product.title}`,
      unreadCount: 0,
      timestamp: new Date().toISOString()
    };
    storageService.saveChat(chatPreview);

    // 3. Navigate to Deal
    setSelectedDealId(newDeal.id);
    handleNavigate(AppScreen.DEAL_DETAIL);
  };

  const handleOpenChat = (chatId: string) => {
    setSelectedChatId(chatId);
    handleNavigate(AppScreen.CHAT_DETAIL);
  };

  const handleOpenDeal = (dealId: string) => {
    setSelectedDealId(dealId);
    handleNavigate(AppScreen.DEAL_DETAIL);
  };

  const handleOpenSellerProfile = (sellerId: number) => {
    setSelectedSellerId(sellerId);
    handleNavigate(AppScreen.SELLER_PROFILE);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case AppScreen.MARKET:
        return <MarketScreen onBuy={handleBuyProduct} onSellerClick={handleOpenSellerProfile} />;
      case AppScreen.CHAT_LIST:
        return <ChatListScreen onChatSelect={handleOpenChat} />;
      case AppScreen.PROFILE:
        return <ProfileScreen onDealSelect={handleOpenDeal} />;
      case AppScreen.DEAL_DETAIL:
        return <DealScreen dealId={selectedDealId!} onBack={() => handleNavigate(AppScreen.PROFILE)} />;
      case AppScreen.CHAT_DETAIL:
        return <ChatScreen chatId={selectedChatId!} onBack={() => handleNavigate(AppScreen.CHAT_LIST)} />;
      case AppScreen.SELLER_PROFILE:
        return <SellerProfileScreen sellerId={selectedSellerId!} onBack={() => handleNavigate(AppScreen.MARKET)} />;
      default:
        return <MarketScreen onBuy={handleBuyProduct} onSellerClick={handleOpenSellerProfile} />;
    }
  };

  const showNav = [AppScreen.MARKET, AppScreen.CHAT_LIST, AppScreen.PROFILE].includes(currentScreen);

  return (
    <div className="min-h-screen bg-[#09090b] text-white pb-32 font-sans overflow-x-hidden">
      <SplashScreen onComplete={() => setLoading(false)} />
      
      {!loading && (
        <div className="max-w-md mx-auto min-h-screen relative">
          <main className="h-full">
            {/* Added key prop for animation reset and wrapper div for page transition */}
            <div key={currentScreen} className="animate-page-enter h-full">
              {renderScreen()}
            </div>
          </main>
          
          {showNav && (
            <BottomNav activeTab={activeTab} onTabChange={handleNavigate} />
          )}
        </div>
      )}
    </div>
  );
};

const App = () => (
  <LanguageProvider>
    <AppContent />
  </LanguageProvider>
);

export default App;