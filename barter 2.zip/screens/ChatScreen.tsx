import React, { useState, useEffect, useRef } from 'react';
import { Message, Attachment } from '../types';
import { storageService } from '../services/storageService';
import { ArrowLeft, Send, Paperclip, File, Check, CheckCheck } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface ChatScreenProps {
  chatId: string;
  onBack: () => void;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({ chatId, onBack }) => {
  const { t } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMessages(storageService.getMessages(chatId));
  }, [chatId]);

  // Simulation: Mark my sent messages as read after a delay to simulate partner reading
  useEffect(() => {
    const unreadMyMessages = messages.some(m => m.senderId === 100 && m.status !== 'read');
    
    if (unreadMyMessages) {
        const timer = setTimeout(() => {
            storageService.markAllAsRead(chatId);
            setMessages(storageService.getMessages(chatId));
        }, 1500); // Partner reads after 1.5s
        return () => clearTimeout(timer);
    }
  }, [messages, chatId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (attachments: Attachment[] = []) => {
    if ((!inputText.trim() && attachments.length === 0)) return;
    
    const newMessage: Message = {
      id: `m_${Date.now()}`,
      chatId,
      senderId: 100, // Mock User ID
      text: inputText,
      attachments,
      timestamp: new Date().toISOString(),
      status: 'sent'
    };

    storageService.saveMessage(newMessage);
    setMessages([...messages, newMessage]);
    setInputText('');
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            const attachment: Attachment = {
                id: `att_${Date.now()}`,
                type: file.type.startsWith('image/') ? 'image' : 'file',
                url: base64String,
                name: file.name,
                size: `${(file.size / 1024).toFixed(0)} KB`
            };
            handleSend([attachment]);
        };
        reader.readAsDataURL(file);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex flex-col h-screen bg-[#09090b]">
      {/* Header */}
      <div className="p-4 pt-6 bg-white/5 backdrop-blur-xl border-b border-white/10 flex items-center gap-4 z-10">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-300 hover:text-white">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h2 className="font-bold text-lg">{t('chat.header')}</h2>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isMe = msg.senderId === 100;
          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                isMe 
                  ? 'bg-neonPurple text-white rounded-br-none' 
                  : 'bg-white/10 text-gray-200 rounded-bl-none'
              }`}>
                 {/* Attachments */}
                  {msg.attachments?.map(att => (
                      <div key={att.id} className="mb-2">
                          {att.type === 'image' ? (
                              <img src={att.url} alt="attachment" className="rounded-lg max-w-full max-h-48 object-cover border border-white/10" />
                          ) : (
                              <div className="flex items-center gap-2 bg-black/20 p-2 rounded-lg">
                                  <File size={20} className="text-white/80" />
                                  <div className="overflow-hidden">
                                      <div className="text-xs font-bold truncate text-white">{att.name}</div>
                                      <div className="text-[10px] text-white/60">{att.size}</div>
                                  </div>
                              </div>
                          )}
                      </div>
                  ))}
                {msg.text && <p className="text-sm">{msg.text}</p>}
                
                <div className={`flex items-end justify-end gap-1 mt-1 ${isMe ? 'opacity-90' : 'opacity-60'}`}>
                    <span className="text-[10px]">
                        {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </span>
                    {isMe && (
                        msg.status === 'read' ? (
                            <CheckCheck size={14} className="text-white" />
                        ) : (
                            <Check size={14} className="text-white/70" />
                        )
                    )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 pb-8 bg-[#09090b] border-t border-white/10">
        <div className="flex gap-2 items-center">
          <input 
             type="file" 
             ref={fileInputRef}
             className="hidden"
             onChange={handleFileSelect}
          />
          <button 
             onClick={() => fileInputRef.current?.click()}
             className="p-3 rounded-full bg-white/5 text-gray-400 hover:text-white border border-white/5 hover:bg-white/10 transition-colors"
          >
             <Paperclip size={20} />
          </button>
          
          <input 
            type="text" 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={t('chat.type_message')}
            className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-3 focus:outline-none focus:border-neonPurple/50"
          />
          <button 
            onClick={() => handleSend()}
            disabled={!inputText.trim()}
            className={`w-12 h-12 rounded-full flex items-center justify-center text-white active:scale-90 transition-transform shadow-[0_0_10px_rgba(139,92,246,0.3)] ${
                inputText.trim() ? 'bg-neonPurple' : 'bg-white/10 text-gray-500'
            }`}
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};