import React from 'react';
import { storageService } from '../services/storageService';
import { GlassCard } from '../components/GlassCard';
import { MessageCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface ChatListScreenProps {
  onChatSelect: (chatId: string) => void;
}

export const ChatListScreen: React.FC<ChatListScreenProps> = ({ onChatSelect }) => {
  const { t } = useLanguage();
  const chats = storageService.getChats();

  return (
    <div className="p-4 pt-6 space-y-4">
      <h1 className="text-2xl font-bold tracking-tight mb-6">{t('chat.title')}</h1>
      
      {/* Support Chat Static */}
      <GlassCard onClick={() => onChatSelect('support')} className="flex items-center gap-4 border-neonBlue/30 bg-neonBlue/5">
        <div className="w-12 h-12 rounded-full bg-neonBlue/20 flex items-center justify-center text-neonBlue">
          <MessageCircle size={24} />
        </div>
        <div>
          <h3 className="font-semibold text-white">{t('chat.support')}</h3>
          <p className="text-sm text-neonBlue/80">{t('chat.support_msg')}</p>
        </div>
      </GlassCard>

      <div className="space-y-3">
        {chats.map((chat) => (
          <GlassCard key={chat.id} onClick={() => onChatSelect(chat.id)} className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gray-700 overflow-hidden border border-white/10">
              {chat.partnerAvatar && <img src={chat.partnerAvatar} alt="" className="w-full h-full object-cover" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-baseline">
                <h3 className="font-semibold text-white truncate">{chat.partnerName}</h3>
                <span className="text-xs text-gray-500">{new Date(chat.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
              </div>
              <p className="text-sm text-gray-400 truncate">{chat.lastMessage}</p>
            </div>
            {chat.unreadCount > 0 && (
              <div className="w-5 h-5 rounded-full bg-neonPurple flex items-center justify-center text-[10px] font-bold">
                {chat.unreadCount}
              </div>
            )}
          </GlassCard>
        ))}
        {chats.length === 0 && (
          <div className="text-center text-gray-500 py-10">
            {t('chat.no_messages')}
          </div>
        )}
      </div>
    </div>
  );
};