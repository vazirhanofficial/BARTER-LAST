import React, { useState, useMemo, useRef } from 'react';
import { Product, Currency } from '../types';
import { storageService } from '../services/storageService';
import { GlassCard } from '../components/GlassCard';
import { NeonButton } from '../components/NeonButton';
import { Search, Filter, Star, Plus, X, ChevronDown, CheckCircle, ArrowDown, ArrowUp, Calendar, ArrowRightLeft, Flame, Medal, Trophy } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface MarketScreenProps {
  onBuy: (product: Product) => void;
  onSellerClick: (sellerId: number) => void;
}

type SortOption = 'date' | 'price_asc' | 'price_desc' | 'rating';

export const MarketScreen: React.FC<MarketScreenProps> = ({ onBuy, onSellerClick }) => {
  const { t } = useLanguage();
  const [products, setProducts] = useState<Product[]>(storageService.getProducts());
  const [searchQuery, setSearchQuery] = useState('');
  
  // Filtering & Sorting State
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState<Currency | 'ALL'>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<SortOption>('date');

  // Create Listing State
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPrice, setNewPrice] = useState<string>('');
  const [newCurrency, setNewCurrency] = useState<Currency>('USD');
  const [newCategory, setNewCategory] = useState('Games');

  // Swipe to Close State
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const startY = useRef(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    // Only allow dragging from the top header area or if scrolled to top
    startY.current = e.touches[0].clientY;
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const currentY = e.touches[0].clientY;
    const diff = currentY - startY.current;
    
    // Only allow dragging down
    if (diff > 0) {
      setDragOffset(diff);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    if (dragOffset > 150) { // Threshold to close
      setShowCreate(false);
    }
    setDragOffset(0);
  };

  // Reset state when modal opens/closes
  useMemo(() => {
    if (!showCreate) {
      setDragOffset(0);
      setIsDragging(false);
    }
  }, [showCreate]);

  // Categories list for the horizontal filter
  const categoryFilters = ['ALL', 'Games', 'Services', 'Accounts', 'Keys', 'Exchange', 'Other'];
  
  // Available categories for creation
  const createCategories = ['Games', 'Services', 'Accounts', 'Keys', 'Exchange', 'Other'];

  const filteredProducts = useMemo(() => {
    let result = products.filter(p => {
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCurrency = selectedCurrency === 'ALL' || p.currency === selectedCurrency;
      const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
      return matchesSearch && matchesCurrency && matchesCategory;
    });

    return result.sort((a, b) => {
      switch (sortBy) {
        case 'price_asc': return a.price - b.price;
        case 'price_desc': return b.price - a.price;
        case 'rating': return b.sellerRating - a.sellerRating;
        case 'date': default: return new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime();
      }
    });
  }, [products, searchQuery, selectedCurrency, selectedCategory, sortBy]);

  const handleCreateListing = () => {
    if (!newTitle || !newPrice) return;

    const user = storageService.getUser();
    const newProduct: Product = {
      id: `p_${Date.now()}`,
      sellerId: user.id,
      sellerName: user.username,
      sellerAvatar: user.avatar_url,
      sellerRating: user.rating,
      title: newTitle,
      description: newDesc,
      price: parseFloat(newPrice),
      currency: newCurrency,
      category: newCategory,
      date: new Date().toISOString()
    };

    storageService.saveProduct(newProduct);
    setProducts([newProduct, ...products]);
    setShowCreate(false);
    
    // Reset form
    setNewTitle('');
    setNewDesc('');
    setNewPrice('');
  };

  const netIncome = newPrice ? (parseFloat(newPrice) * 0.9).toFixed(2) : '0.00';
  
  // Helper for translations
  const getCatLabel = (cat: string) => {
    return t(`market.categories.${cat.toLowerCase()}`);
  };

  // Helper to determine rank based on deal count (simulated)
  const getRank = (sellerId: number) => {
      const dealCount = storageService.getSellerDeals(sellerId).length;
      if (dealCount >= 1000) return 'legend';
      if (dealCount >= 500) return 'veteran';
      if (dealCount >= 100) return 'pro';
      return 'novice';
  };

  return (
    <div className="p-4 pt-6 space-y-6 relative min-h-screen">
      
      {/* --- CREATE LISTING MODAL --- */}
      {showCreate && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center">
          <div 
            className="absolute inset-0 bg-black/80 backdrop-blur-md animate-fade-in duration-300" 
            style={{ opacity: Math.max(0, 1 - dragOffset / 400) }}
            onClick={() => setShowCreate(false)} 
          />
          <div 
            className="relative w-full max-w-md p-4 animate-slide-up"
            style={{ 
              transform: `translateY(${dragOffset}px)`,
              transition: isDragging ? 'none' : 'transform 0.4s cubic-bezier(0.2, 0.8, 0.2, 1)'
            }}
          >
            {/* Drag Handle Area */}
            <div 
              className="absolute top-0 left-0 right-0 h-12 z-20 flex justify-center items-start pt-2 cursor-grab active:cursor-grabbing"
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
            >
              <div className="w-12 h-1.5 bg-white/20 rounded-full" />
            </div>

            <GlassCard className="bg-[#09090b] border-white/20 shadow-2xl pt-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">{t('create_listing.title')}</h2>
                <button onClick={() => setShowCreate(false)} className="p-2 rounded-full bg-white/10 hover:bg-white/20 interactive-bounce"><X size={20}/></button>
              </div>

              {/* BARTER LOGO - GLASS SWIPE STYLE WITH ANIMATED ICON */}
              <div className="flex justify-center items-center gap-4 mb-6">
                 <div className="text-3xl font-black tracking-widest bg-gradient-to-r from-gray-500 via-white to-gray-500 bg-[length:200%_auto] bg-clip-text text-transparent animate-glass-swipe select-none">
                    BARTER
                 </div>
                 <ArrowRightLeft className="text-white/40 animate-exchange-rotate" size={32} />
              </div>

              <div className="space-y-4">
                <input
                  type="text"
                  placeholder={t('create_listing.name_placeholder')}
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 focus:border-neonPurple focus:outline-none transition-colors"
                />
                
                <textarea
                  placeholder={t('create_listing.desc_placeholder')}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 focus:border-neonPurple focus:outline-none resize-none transition-colors"
                />

                <div className="flex gap-2 items-center">
                   <select 
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 focus:outline-none transition-colors"
                  >
                    {createCategories.map(cat => (
                      <option key={cat} value={cat}>{getCatLabel(cat)}</option>
                    ))}
                  </select>
                </div>

                <div className="flex gap-4 items-center">
                  <div className="flex-1">
                    <label className="text-xs text-green-400 mb-1 block">{t('create_listing.income')}</label>
                    <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-3 text-green-400 font-bold text-center">
                      {netIncome}
                    </div>
                  </div>
                  <div className="flex-1">
                    <label className="text-xs text-gray-400 mb-1 block">{t('create_listing.price')}</label>
                    <div className="relative">
                      <input
                        type="number"
                        value={newPrice}
                        onChange={(e) => setNewPrice(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-3 pr-16 font-bold text-right focus:border-neonPurple focus:outline-none transition-colors"
                        placeholder="0.00"
                      />
                      <div className="absolute inset-y-0 right-1 flex items-center">
                        <select 
                          value={newCurrency} 
                          onChange={(e) => setNewCurrency(e.target.value as Currency)}
                          className="bg-transparent text-xs text-gray-300 font-bold focus:outline-none text-right pr-2"
                        >
                          {['USD', 'RUB', 'USDT', 'BTC', 'ETH'].map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <NeonButton onClick={handleCreateListing} fullWidth className="mt-4">
                  <CheckCircle size={18} /> {t('create_listing.publish')}
                </NeonButton>
              </div>
            </GlassCard>
          </div>
        </div>
      )}

      {/* --- HEADER --- */}
      <div className="flex justify-between items-center z-10 relative">
        {/* BARTER LOGO - GLASS GLOW STYLE (Idle) WITH ANIMATED ICON */}
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold tracking-tight neon-text animate-glass-glow">{t('market.title')}</h1>
          <ArrowRightLeft className="text-neonPurple animate-exchange-rotate" size={24} />
        </div>
        
        <div className="flex gap-2">
           <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2 rounded-full border transition-all duration-300 interactive-bounce ${showFilters ? 'bg-neonPurple text-white border-neonPurple' : 'bg-white/5 border-white/10'}`}
          >
            <Filter size={20} />
          </button>
          <button 
            onClick={() => setShowCreate(true)}
            className="p-2 bg-gradient-to-r from-neonPurple to-neonBlue rounded-full border border-white/10 interactive-bounce shadow-[0_0_15px_rgba(139,92,246,0.3)]"
          >
            <Plus size={20} className="text-white" />
          </button>
        </div>
      </div>

      {/* --- FILTER PANEL --- */}
      {showFilters && (
        <GlassCard className="animate-pop-in origin-top space-y-4 border-neonPurple/30 bg-black/40">
           <div className="flex justify-between items-center">
              <h3 className="font-bold text-sm text-gray-300">{t('market.filters.title')}</h3>
              <button 
                onClick={() => {
                  setSortBy('date');
                  setSelectedCategory('ALL');
                  setSelectedCurrency('ALL');
                }}
                className="text-xs text-neonBlue hover:underline"
              >
                {t('market.filters.reset')}
              </button>
           </div>
           
           {/* Currency Selection (Formerly Category) */}
           <div className="space-y-1">
             <label className="text-xs text-gray-500">{t('market.filters.currency')}</label>
             <div className="relative">
                <select
                  value={selectedCurrency}
                  onChange={(e) => setSelectedCurrency(e.target.value as any)}
                  className="w-full appearance-none bg-white/5 border border-white/10 rounded-lg p-2.5 text-sm focus:outline-none focus:border-neonPurple transition-colors"
                >
                  <option value="ALL">{t('market.filters.all')}</option>
                  {['RUB', 'USD', 'USDT', 'BTC', 'ETH', 'SOL'].map(curr => (
                    <option key={curr} value={curr}>{curr}</option>
                  ))}
                </select>
                <ChevronDown size={16} className="absolute right-3 top-3 text-gray-400 pointer-events-none"/>
             </div>
           </div>

           {/* Sorting */}
           <div className="space-y-2">
             <label className="text-xs text-gray-500">{t('market.filters.sort_by')}</label>
             <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'date', label: t('market.filters.date'), icon: Calendar },
                  { id: 'rating', label: t('market.filters.rating'), icon: Star },
                  { id: 'price_asc', label: t('market.filters.price_asc'), icon: ArrowUp },
                  { id: 'price_desc', label: t('market.filters.price_desc'), icon: ArrowDown }
                ].map((opt) => (
                  <button 
                    key={opt.id}
                    onClick={() => setSortBy(opt.id as SortOption)}
                    className={`interactive-bounce flex items-center justify-center gap-1 p-2 rounded-lg text-xs border transition-colors ${sortBy === opt.id ? 'bg-neonPurple/20 border-neonPurple text-white' : 'bg-white/5 border-white/10 text-gray-400'}`}
                  >
                    <opt.icon size={14} /> {opt.label}
                  </button>
                ))}
             </div>
           </div>
        </GlassCard>
      )}

      {/* Search */}
      <div className="relative group">
        <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
          <Search size={18} className="text-gray-400 group-focus-within:text-neonBlue transition-colors duration-300" />
        </div>
        <input
          type="text"
          placeholder={t('market.search')}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-neonBlue/50 focus:bg-white/10 transition-all duration-300"
        />
      </div>

      {/* Category Filters (Horizontal Scroll) - REPLACED CURRENCY FILTERS */}
      <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-2">
        {categoryFilters.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`interactive-bounce px-4 py-1.5 rounded-lg text-sm font-medium border transition-all duration-300 whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-neonPurple/20 border-neonPurple text-white shadow-[0_0_10px_rgba(139,92,246,0.2)]'
                : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
            }`}
          >
            {getCatLabel(cat)}
          </button>
        ))}
      </div>

      {/* Product Grid - With Staggered Animation */}
      <div className="grid gap-4 pb-20">
        {filteredProducts.map((product, index) => {
          const rank = getRank(product.sellerId);
          
          return (
            <div key={product.id} className="animate-pop-in" style={{ animationDelay: `${index * 0.05}s`, opacity: 0 }}>
              <GlassCard className="flex flex-col gap-3">
                <div className="flex justify-between items-start">
                  {/* Make seller info clickable */}
                  <div 
                    className="flex items-center gap-3 cursor-pointer group rounded-full pr-2 hover:bg-white/5 transition-colors"
                    onClick={(e) => { e.stopPropagation(); onSellerClick(product.sellerId); }}
                  >
                    {/* AVATAR WITH RANK EFFECTS */}
                    <div className={`w-10 h-10 rounded-full overflow-hidden border transition-all relative
                       ${rank === 'legend' ? 'border-orange-500/80 shadow-[0_0_15px_rgba(239,68,68,0.5)] animate-fire-border' : 
                         rank === 'veteran' ? 'border-blue-300/60 shadow-[0_0_10px_rgba(148,163,184,0.4)]' : 
                         rank === 'pro' ? 'border-neonBlue/60 shadow-[0_0_8px_rgba(59,130,246,0.3)]' : 
                         'border-white/10 bg-gradient-to-tr from-gray-700 to-gray-600'}`}
                    >
                      {product.sellerAvatar && <img src={product.sellerAvatar} alt="Seller" className="w-full h-full object-cover" />}
                      
                      {/* Legend rank fire effect overlay */}
                      {rank === 'legend' && (
                         <div className="absolute inset-0 bg-orange-500/10 mix-blend-overlay animate-pulse"></div>
                      )}
                    </div>

                    <div>
                      {/* NAME WITH RANK EFFECTS */}
                      <div className="flex items-center gap-1.5">
                          <h3 className={`font-semibold text-sm transition-colors
                             ${rank === 'legend' ? 'bg-fire bg-clip-text text-transparent animate-fire-text font-black' : 
                               rank === 'veteran' ? 'bg-diamond bg-clip-text text-transparent font-bold animate-diamond-shine' : 
                               rank === 'pro' ? 'text-neonBlue neon-text' : 
                               'text-gray-200 group-hover:text-white'}`}>
                              {product.sellerName}
                          </h3>
                          
                          {/* RANK ICONS */}
                          {rank === 'legend' && <Flame size={12} className="text-orange-500 animate-living-fire fill-orange-500" />}
                          {rank === 'veteran' && <Star size={10} className="text-blue-200 animate-pulse fill-blue-200" />}
                          {rank === 'pro' && <Medal size={10} className="text-neonBlue" />}
                      </div>

                      <div className="flex items-center gap-1 text-xs text-yellow-400/90">
                        <Star size={10} fill="currentColor" />
                        <span>{product.sellerRating}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="block text-lg font-bold text-white">
                      {product.price} <span className="text-xs text-neonPurple font-normal align-top">{product.currency}</span>
                    </span>
                    <span className="text-[10px] text-gray-500 block">
                      {new Date(product.date || Date.now()).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-medium leading-tight mb-1">{product.title}</h2>
                  <p className="text-sm text-gray-400 line-clamp-2">{product.description}</p>
                  <span className="inline-block mt-2 px-2 py-0.5 rounded-md bg-white/5 text-[10px] text-gray-400 border border-white/5">
                    {getCatLabel(product.category)}
                  </span>
                </div>

                <NeonButton onClick={(e) => { e.stopPropagation(); onBuy(product); }} fullWidth className="mt-2 text-sm py-2.5">
                  {t('market.purchase')}
                </NeonButton>
              </GlassCard>
            </div>
          );
        })}
        {filteredProducts.length === 0 && (
          <div className="text-center text-gray-500 py-10 animate-fade-in">
            {t('market.no_offers')}
          </div>
        )}
      </div>
    </div>
  );
};