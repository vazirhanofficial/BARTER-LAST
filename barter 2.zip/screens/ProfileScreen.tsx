import React, { useState, useEffect, useRef } from 'react';
import { storageService } from '../services/storageService';
import { GlassCard } from '../components/GlassCard';
import { PaymentModal } from '../components/PaymentModal';
import { VerificationModal } from '../components/VerificationModal';
import { useLanguage } from '../contexts/LanguageContext';
import { 
  ChevronDown, CreditCard, History, Star, 
  Camera, Edit2, Check, X, ArrowUpRight, ArrowDownLeft, Settings, Globe, Shield, Smartphone, Mail, ChevronRight, Trophy, Medal, Flame, BadgeCheck
} from 'lucide-react';
import { Currency } from '../types';

interface ProfileScreenProps {
  onDealSelect: (dealId: string) => void;
}

type TimeRange = 7 | 30 | 90;

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ onDealSelect }) => {
  const { t, language, setLanguage } = useLanguage();
  const allDeals = storageService.getDeals();
  const [user, setUser] = useState(storageService.getUser());
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('USD');
  
  // Filter deals for current user
  const userDeals = allDeals.filter(d => d.buyerId === user.id || d.sellerId === user.id);

  // Stats State
  const [timeRange, setTimeRange] = useState<TimeRange>(30);
  const [stats, setStats] = useState(0);

  // UI State
  const [isEditing, setIsEditing] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [editName, setEditName] = useState(user.username);
  
  // Binding State
  const [bindMode, setBindMode] = useState<'phone' | 'email' | null>(null);
  const [bindValue, setBindValue] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modal State
  const [modalType, setModalType] = useState<'deposit' | 'withdraw' | null>(null);
  const [showVerifyModal, setShowVerifyModal] = useState(false);

  useEffect(() => {
    setUser(storageService.getUser());
    setStats(storageService.getSellerStats(storageService.getUser().id, timeRange));
  }, [timeRange]);

  // Rank Logic
  const getRank = (count: number) => {
    if (count >= 1000) return 'legend';
    if (count >= 500) return 'veteran';
    if (count >= 100) return 'pro';
    return 'novice';
  };

  const rank = getRank(userDeals.length);

  // Helper to render the specific badge
  const renderRankBadge = () => {
    switch (rank) {
      case 'legend':
        return (
          <div className="relative inline-flex items-center justify-center mt-1 mb-2">
            <div className="phoenix-wing-left"></div>
            <div className="phoenix-wing-right"></div>
            <div className="relative z-10 flex items-center gap-1.5 px-4 py-1 rounded-full border border-orange-500/50 bg-black/60 shadow-[0_0_20px_rgba(239,68,68,0.6)]">
               <Flame size={14} className="text-orange-500 animate-pulse fill-orange-500" />
               <span className="text-[10px] font-black uppercase tracking-wider bg-fire bg-clip-text text-transparent animate-fire-text">
                 {t(`profile.ranks.${rank}`)}
               </span>
               <Flame size={14} className="text-orange-500 animate-pulse fill-orange-500" />
            </div>
          </div>
        );
      case 'veteran':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-slate-400/50 text-[10px] font-black uppercase tracking-wider mb-2 bg-diamond animate-diamond-shine text-white shadow-[0_0_15px_rgba(148,163,184,0.5)]">
             <Star size={12} fill="currentColor" className="text-white" />
             {t(`profile.ranks.${rank}`)}
          </div>
        );
      case 'pro':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-neonBlue text-[10px] font-black uppercase tracking-wider mb-2 bg-neonBlue/10 text-neonBlue animate-neon-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]">
             <Medal size={12} />
             {t(`profile.ranks.${rank}`)}
          </div>
        );
      default: // Novice
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-white/10 text-[10px] font-black uppercase tracking-wider mb-2 bg-white/5 text-gray-400">
             <Medal size={12} />
             {t(`profile.ranks.${rank}`)}
          </div>
        );
    }
  };

  const handleSaveProfile = () => {
    // Mark profile as modified so sync doesn't overwrite it later
    const updatedUser = { ...user, username: editName, isProfileModified: true };
    storageService.saveUser(updatedUser);
    setUser(updatedUser);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditName(user.username);
    setIsEditing(false);
  };

  const handleAvatarClick = () => {
    if (isEditing) {
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        // Mark as modified when avatar is changed
        const updatedUser = { ...user, avatar_url: base64String, isProfileModified: true };
        storageService.saveUser(updatedUser);
        setUser(updatedUser);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaymentConfirm = (amount: number, currency: Currency) => {
    // Deep clone user to update nested balance object
    const updatedUser = JSON.parse(JSON.stringify(user));
    
    // Ensure balance object exists for the currency
    if (updatedUser.balance[currency] === undefined) {
        updatedUser.balance[currency] = 0;
    }

    if (modalType === 'deposit') {
        updatedUser.balance[currency] += amount;
    } else if (modalType === 'withdraw') {
        if (updatedUser.balance[currency] >= amount) {
            updatedUser.balance[currency] -= amount;
        } else {
            // Should handle error, but for now just don't subtract
            return; 
        }
    }

    storageService.saveUser(updatedUser);
    setUser(updatedUser);
    setModalType(null);
  };

  const handleBindSave = () => {
    if (bindMode === 'phone') {
      const updated = { ...user, phone: bindValue };
      storageService.saveUser(updated);
      setUser(updated);
    } else if (bindMode === 'email') {
      const updated = { ...user, email: bindValue };
      storageService.saveUser(updated);
      setUser(updated);
    }
    setBindMode(null);
    setBindValue('');
  };

  const handleGoogleAuthToggle = () => {
      const updated = { ...user, googleAuthEnabled: !user.googleAuthEnabled };
      storageService.saveUser(updated);
      setUser(updated);
  };

  const handleVerificationSubmit = (data: any) => {
      // In a real app, send data to backend. Here we update status to verified.
      const updated = { ...user, verificationStatus: 'verified' };
      storageService.saveUser(updated);
      setUser(updated as any);
      setShowVerifyModal(false);
  };

  // --- Settings View ---
  if (showSettings) {
    return (
      <div className="p-4 pt-6 space-y-6 pb-24 min-h-screen relative animate-fade-in flex flex-col">
        <VerificationModal 
            isOpen={showVerifyModal} 
            onClose={() => setShowVerifyModal(false)} 
            onVerify={handleVerificationSubmit}
        />

        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => setShowSettings(false)} className="p-2 -ml-2 text-gray-300 hover:text-white">
            <ChevronRight className="rotate-180" size={24} />
          </button>
          <h2 className="font-bold text-xl">{t('settings.title')}</h2>
        </div>

        {/* Language */}
        <div className="space-y-2">
          <label className="text-xs text-gray-500 uppercase font-semibold ml-1">{t('settings.language')}</label>
          <GlassCard className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-gray-200">
              <Globe size={20} className="text-neonBlue" />
              <span>{language === 'en' ? 'English' : 'Русский'}</span>
            </div>
            <select 
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-white/10 border border-white/10 rounded-lg px-2 py-1 text-sm focus:outline-none"
            >
              <option value="en">English</option>
              <option value="ru">Русский</option>
            </select>
          </GlassCard>
        </div>

        {/* Security / Binding */}
        <div className="space-y-4">
          <label className="text-xs text-gray-500 uppercase font-semibold ml-1">{t('settings.security')}</label>
          
          {/* Identity Verification */}
          <GlassCard onClick={() => user.verificationStatus !== 'verified' && setShowVerifyModal(true)}>
            <div className="flex items-center gap-3 mb-3 text-gray-200">
              <BadgeCheck size={20} className={user.verificationStatus === 'verified' ? "text-blue-400" : "text-neonPurple"} />
              <span className="flex-1">{t('settings.verification')}</span>
            </div>
            <div className="flex justify-between items-center pl-8">
              <span className={`text-sm ${
                  user.verificationStatus === 'verified' ? 'text-blue-400 font-bold' : 
                  user.verificationStatus === 'pending' ? 'text-yellow-400' : 'text-gray-400'
              }`}>
                {user.verificationStatus === 'verified' ? t('settings.verified') : 
                 user.verificationStatus === 'pending' ? t('settings.pending') : 
                 t('settings.not_set')}
              </span>
              {user.verificationStatus !== 'verified' && (
                  <button className="text-sm text-neonBlue font-medium hover:underline">
                     {t('settings.enable')}
                  </button>
              )}
            </div>
          </GlassCard>

          {/* Phone */}
          <GlassCard>
            <div className="flex items-center gap-3 mb-3 text-gray-200">
              <Smartphone size={20} className="text-neonPurple" />
              <span className="flex-1">{t('settings.phone')}</span>
            </div>
            {bindMode === 'phone' ? (
              <div className="flex gap-2">
                <input 
                  type="tel" 
                  value={bindValue}
                  onChange={(e) => setBindValue(e.target.value)}
                  placeholder="+1..."
                  className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-neonPurple"
                  autoFocus
                />
                <button onClick={handleBindSave} className="px-3 py-1 bg-neonPurple text-white rounded-lg text-sm">{t('settings.saved')}</button>
                <button onClick={() => setBindMode(null)} className="px-3 py-1 bg-white/10 rounded-lg text-sm"><X size={16}/></button>
              </div>
            ) : (
              <div className="flex justify-between items-center pl-8">
                <span className="text-sm text-gray-400">{user.phone || t('settings.not_set')}</span>
                <button 
                  onClick={() => { setBindMode('phone'); setBindValue(user.phone || ''); }}
                  className="text-sm text-neonBlue font-medium hover:underline"
                >
                  {user.phone ? t('settings.change') : t('settings.bind')}
                </button>
              </div>
            )}
          </GlassCard>

          {/* Email */}
          <GlassCard>
            <div className="flex items-center gap-3 mb-3 text-gray-200">
              <Mail size={20} className="text-neonPurple" />
              <span className="flex-1">{t('settings.email')}</span>
            </div>
            {bindMode === 'email' ? (
              <div className="flex gap-2">
                <input 
                  type="email" 
                  value={bindValue}
                  onChange={(e) => setBindValue(e.target.value)}
                  placeholder="user@example.com"
                  className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-neonPurple"
                  autoFocus
                />
                <button onClick={handleBindSave} className="px-3 py-1 bg-neonPurple text-white rounded-lg text-sm">{t('settings.saved')}</button>
                <button onClick={() => setBindMode(null)} className="px-3 py-1 bg-white/10 rounded-lg text-sm"><X size={16}/></button>
              </div>
            ) : (
              <div className="flex justify-between items-center pl-8">
                <span className="text-sm text-gray-400">{user.email || t('settings.not_set')}</span>
                <button 
                  onClick={() => { setBindMode('email'); setBindValue(user.email || ''); }}
                  className="text-sm text-neonBlue font-medium hover:underline"
                >
                   {user.email ? t('settings.change') : t('settings.bind')}
                </button>
              </div>
            )}
          </GlassCard>

          {/* Google Authenticator */}
          <GlassCard>
            <div className="flex items-center gap-3 mb-3 text-gray-200">
              <Shield size={20} className="text-neonPurple" />
              <span className="flex-1">{t('settings.google_auth')}</span>
            </div>
            <div className="flex justify-between items-center pl-8">
              <span className={`text-sm ${user.googleAuthEnabled ? 'text-green-400' : 'text-gray-400'}`}>
                {user.googleAuthEnabled ? t('settings.enabled') : t('settings.not_set')}
              </span>
              <button 
                onClick={handleGoogleAuthToggle}
                className="text-sm text-neonBlue font-medium hover:underline"
              >
                 {user.googleAuthEnabled ? t('settings.disable') : t('settings.enable')}
              </button>
            </div>
          </GlassCard>
        </div>

        {/* Footer with Neon Text - Removed Pulse Animation */}
        <div className="mt-auto pt-8 flex justify-center items-end opacity-70">
            <div className="text-[10px] font-bold tracking-[0.2em] text-neonPurple neon-text drop-shadow-[0_0_5px_rgba(139,92,246,0.8)] text-center">
                POWERED BY VAZIRHAN & KENS
            </div>
        </div>
      </div>
    );
  }

  // --- Profile View ---
  return (
    <div className="p-4 pt-6 space-y-6 pb-24 relative animate-fade-in">
      <PaymentModal 
        isOpen={!!modalType} 
        type={modalType} 
        onClose={() => setModalType(null)} 
        onConfirm={handlePaymentConfirm} 
      />

      {/* Settings Button */}
      <button 
        onClick={() => setShowSettings(true)}
        className="absolute top-6 right-4 p-2 bg-white/5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white z-10 transition-colors"
      >
        <Settings size={20} />
      </button>

      {/* Profile Header */}
      <div className="flex flex-col items-center gap-4 relative">
        <div className="relative group">
          <div 
            onClick={handleAvatarClick}
            className={`w-28 h-28 rounded-full p-1 bg-gradient-to-tr from-neonPurple to-neonBlue shadow-[0_0_20px_rgba(139,92,246,0.3)] ${isEditing ? 'cursor-pointer hover:opacity-90' : ''}`}
          >
            <img src={user.avatar_url} alt="Profile" className="w-full h-full rounded-full object-cover border-2 border-[#09090b]" />
            
            {isEditing && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full backdrop-blur-[2px]">
                <Camera size={24} className="text-white" />
              </div>
            )}
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            className="hidden" 
            accept="image/*"
          />
        </div>

        <div className="text-center w-full max-w-[200px] flex flex-col items-center">
          {isEditing ? (
            <div className="flex items-center gap-2 mb-2">
              <input 
                type="text" 
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-lg px-2 py-1 text-center font-bold focus:outline-none focus:border-neonPurple"
                autoFocus
              />
              <button onClick={handleSaveProfile} className="p-1.5 bg-green-500/20 text-green-400 rounded-full hover:bg-green-500/30">
                <Check size={16} />
              </button>
              <button onClick={handleCancelEdit} className="p-1.5 bg-red-500/20 text-red-400 rounded-full hover:bg-red-500/30">
                <X size={16} />
              </button>
            </div>
          ) : (
            <div className="relative inline-flex items-center gap-2 mb-2">
              <h2 className="text-xl font-bold flex items-center gap-1.5">
                  {user.username}
                  {user.verificationStatus === 'verified' && (
                      <BadgeCheck size={18} className="text-blue-400 fill-blue-400/10" />
                  )}
              </h2>
              <button 
                onClick={() => setIsEditing(true)}
                className="p-1 text-gray-500 hover:text-white transition-colors"
              >
                <Edit2 size={14} />
              </button>
            </div>
          )}

          {/* Rank Badge Rendered Here */}
          {renderRankBadge()}
          
          <div className="flex items-center justify-center gap-1 text-yellow-400 mt-1">
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" className="opacity-50" />
            <span className="text-xs text-gray-400 ml-1">({user.rating})</span>
          </div>
        </div>
      </div>

      {/* Balance Card */}
      <GlassCard className="relative overflow-hidden group">
        <div className="absolute -right-10 -top-10 w-32 h-32 bg-neonBlue/20 rounded-full blur-3xl"></div>
        <div className="flex justify-between items-start mb-2">
          <span className="text-gray-400 text-sm flex items-center gap-2">
            <CreditCard size={14} /> {t('profile.balance')}
          </span>
          <div className="relative z-10">
            <select 
              value={selectedCurrency}
              onChange={(e) => setSelectedCurrency(e.target.value as Currency)}
              className="appearance-none bg-black/40 border border-white/10 rounded-lg py-1 pl-3 pr-8 text-xs font-medium focus:outline-none backdrop-blur-md"
            >
              {['USD', 'RUB', 'USDT', 'BTC', 'ETH', 'SOL'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2 top-2 pointer-events-none text-gray-400" />
          </div>
        </div>
        <div className="text-3xl font-bold tracking-tight mb-4">
          {selectedCurrency === 'BTC' ? '₿' : selectedCurrency === 'EUR' ? '€' : selectedCurrency === 'RUB' ? '₽' : '$'}
          {(user as any).balance[selectedCurrency].toLocaleString()}
        </div>

        {/* Deposit/Withdraw Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => setModalType('deposit')}
            className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-neonPurple/20 text-neonPurple border border-neonPurple/30 font-semibold text-sm hover:bg-neonPurple/30 active:scale-95 transition-all"
          >
            <ArrowDownLeft size={16} />
            {t('profile.deposit')}
          </button>
          <button 
             onClick={() => setModalType('withdraw')}
            className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 text-white border border-white/10 font-semibold text-sm hover:bg-white/10 active:scale-95 transition-all"
          >
            <ArrowUpRight size={16} />
            {t('profile.withdraw')}
          </button>
        </div>
      </GlassCard>

      {/* Stats with Filter (Matching Seller Profile) */}
      <GlassCard className="relative overflow-hidden border-white/10 p-0">
          <div className="p-4 flex justify-between items-center bg-white/5">
             <div className="flex items-center gap-2">
                <Trophy size={16} className="text-green-400" />
                <span className="text-xs font-bold uppercase text-gray-300">{t('seller_profile.successful_deals')}</span>
             </div>
             <div className="relative">
                <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(Number(e.target.value) as TimeRange)}
                    className="appearance-none bg-black/40 border border-white/10 rounded-lg py-1 pl-2 pr-6 text-[10px] font-bold focus:outline-none backdrop-blur-md text-neonBlue cursor-pointer hover:bg-black/60 transition-colors"
                >
                    <option value={7}>{t('seller_profile.period.days_7')}</option>
                    <option value={30}>{t('seller_profile.period.days_30')}</option>
                    <option value={90}>{t('seller_profile.period.days_90')}</option>
                </select>
                <ChevronDown size={10} className="absolute right-1.5 top-2 pointer-events-none text-gray-400" />
            </div>
          </div>
          <div className="grid grid-cols-2 divide-x divide-white/10">
             <div className="p-4 text-center">
                <div key={stats} className="text-2xl font-black text-white animate-pop-in">{stats}</div>
                <div className="text-[10px] text-gray-500 uppercase mt-1">Deals ({timeRange}d)</div>
             </div>
             <div className="p-4 text-center">
                <div className="text-2xl font-black text-white">{userDeals.length}</div>
                <div className="text-[10px] text-gray-500 uppercase mt-1">{t('profile.total_deals')}</div>
             </div>
          </div>
      </GlassCard>

      {/* Deal History */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-gray-300">
          <History size={18} />
          <h3 className="font-semibold">{t('profile.recent_deals')}</h3>
        </div>
        
        <div className="space-y-3">
          {userDeals.slice(0, 50).map(deal => (
            <GlassCard key={deal.id} onClick={() => onDealSelect(deal.id)} className="flex justify-between items-center py-3">
              <div>
                <h4 className="font-medium text-sm">{deal.title}</h4>
                <span className={`text-xs px-2 py-0.5 rounded-full inline-block mt-1 ${
                  deal.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                  deal.status === 'cancelled' ? 'bg-red-500/20 text-red-400' :
                  'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {t(`deal.status.${deal.status}`)}
                </span>
              </div>
              <div className="text-right">
                <div className="font-bold text-sm">{deal.price} {deal.currency}</div>
                <div className="text-xs text-gray-500">{new Date(deal.date).toLocaleDateString()}</div>
              </div>
            </GlassCard>
          ))}
          {userDeals.length === 0 && (
            <div className="text-center text-gray-500 text-sm py-4">{t('profile.no_deals')}</div>
          )}
        </div>
      </div>
    </div>
  );
};