import React, { useState, useEffect, useRef } from 'react';
import { Deal, Message, Attachment } from '../types';
import { storageService } from '../services/storageService';
import { GlassCard } from '../components/GlassCard';
import { NeonButton } from '../components/NeonButton';
import { GoogleAuthModal } from '../components/GoogleAuthModal';
import { ArrowLeft, ShieldCheck, AlertCircle, AlertTriangle, Scale, Send, Paperclip, File, Image as ImageIcon, Check, CheckCheck } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface DealScreenProps {
  dealId: string;
  onBack: () => void;
}

type Tab = 'chat' | 'details';

export const DealScreen: React.FC<DealScreenProps> = ({ dealId, onBack }) => {
  const { t } = useLanguage();
  const [deal, setDeal] = useState<Deal | undefined>(storageService.getDeals().find(d => d.id === dealId));
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  
  // Auth Modal State
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Chat State
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Derive Chat ID from seller (in a real app this would be unique per deal)
  const chatId = deal ? `c_${deal.sellerId}` : '';

  useEffect(() => {
    if (chatId) {
        setMessages(storageService.getMessages(chatId));
    }
  }, [chatId]);

  // Simulation: Mark my sent messages as read after a delay
  useEffect(() => {
    if (!chatId) return;
    const unreadMyMessages = messages.some(m => m.senderId === 100 && m.status !== 'read');
    
    if (unreadMyMessages) {
        const timer = setTimeout(() => {
            storageService.markAllAsRead(chatId);
            setMessages(storageService.getMessages(chatId));
        }, 1500); // Partner reads after 1.5s
        return () => clearTimeout(timer);
    }
  }, [messages, chatId]);

  useEffect(() => {
    if (activeTab === 'chat') {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeTab]);

  if (!deal) return <div className="p-4">{t('deal.not_found')}</div>;

  const handleConfirmClick = () => {
    const user = storageService.getUser();
    if (user.googleAuthEnabled) {
      setShowAuthModal(true);
    } else {
      updateStatus('completed');
    }
  };

  const handleAuthVerify = (code: string) => {
    // Mock Verification Logic
    if (code.length === 6) {
      updateStatus('completed');
      setShowAuthModal(false);
    }
  };

  const updateStatus = (status: Deal['status']) => {
    const updatedDeal = { ...deal, status };
    storageService.saveDeal(updatedDeal);
    setDeal(updatedDeal);
  };

  const handleSend = (attachments: Attachment[] = []) => {
    if ((!inputText.trim() && attachments.length === 0) || !chatId) return;
    
    const newMessage: Message = {
      id: `m_${Date.now()}`,
      chatId,
      senderId: 100, // Mock User ID
      text: inputText,
      attachments,
      timestamp: new Date().toISOString(),
      status: 'sent'
    };

    storageService.saveMessage(newMessage);
    setMessages([...messages, newMessage]);
    setInputText('');
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            const attachment: Attachment = {
                id: `att_${Date.now()}`,
                type: file.type.startsWith('image/') ? 'image' : 'file',
                url: base64String,
                name: file.name,
                size: `${(file.size / 1024).toFixed(0)} KB`
            };
            handleSend([attachment]);
        };
        reader.readAsDataURL(file);
    }
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const renderMessages = () => (
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
          {messages.length === 0 && (
              <div className="text-center text-gray-500 mt-10 text-sm">
                  {t('chat.no_messages')}
              </div>
          )}
          {messages.map((msg) => {
              const isMe = msg.senderId === 100;
              return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl ${
                          isMe ? 'bg-neonPurple text-white rounded-br-none' : 'bg-white/10 text-gray-200 rounded-bl-none'
                      }`}>
                          {/* Attachments */}
                          {msg.attachments?.map(att => (
                              <div key={att.id} className="mb-2">
                                  {att.type === 'image' ? (
                                      <img src={att.url} alt="attachment" className="rounded-lg max-w-full max-h-48 object-cover border border-white/10" />
                                  ) : (
                                      <div className="flex items-center gap-2 bg-black/20 p-2 rounded-lg">
                                          <File size={20} className="text-white/80" />
                                          <div className="overflow-hidden">
                                              <div className="text-xs font-bold truncate text-white">{att.name}</div>
                                              <div className="text-[10px] text-white/60">{att.size}</div>
                                          </div>
                                      </div>
                                  )}
                              </div>
                          ))}

                          {msg.text && <p className="text-sm">{msg.text}</p>}
                          
                          <div className={`flex items-end justify-end gap-1 mt-1 ${isMe ? 'opacity-90' : 'opacity-60'}`}>
                                <span className="text-[10px]">
                                    {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                </span>
                                {isMe && (
                                    msg.status === 'read' ? (
                                        <CheckCheck size={14} className="text-white" />
                                    ) : (
                                        <Check size={14} className="text-white/70" />
                                    )
                                )}
                            </div>
                      </div>
                  </div>
              );
          })}
          <div ref={messagesEndRef} />
      </div>
  );

  return (
    <div className="h-screen bg-[#09090b] flex flex-col">
       <GoogleAuthModal 
         isOpen={showAuthModal}
         onClose={() => setShowAuthModal(false)}
         onVerify={handleAuthVerify}
       />

       {/* Header */}
       <div className="p-4 pt-6 bg-[#09090b] z-10 border-b border-white/5">
            <div className="flex items-center gap-4 mb-4">
                <button onClick={onBack} className="p-2 -ml-2 text-gray-300 hover:text-white">
                    <ArrowLeft size={24} />
                </button>
                <div className="flex-1">
                    <h2 className="font-bold text-lg leading-tight truncate">{deal.title}</h2>
                    <span className={`text-xs uppercase font-bold tracking-wider ${
                        deal.status === 'active' ? 'text-blue-400' :
                        deal.status === 'completed' ? 'text-green-400' :
                        deal.status === 'appeal' ? 'text-orange-400' : 'text-red-400'
                    }`}>
                        {t(`deal.status.${deal.status}`)}
                    </span>
                </div>
                <div className="text-right">
                     <div className="font-bold">{deal.price} {deal.currency}</div>
                     <div className="text-xs text-gray-500">#{deal.id.slice(-4)}</div>
                </div>
            </div>

            {/* Tabs */}
            <div className="grid grid-cols-2 p-1 bg-white/5 rounded-xl">
                <button 
                    onClick={() => setActiveTab('chat')}
                    className={`py-2 rounded-lg text-sm font-bold transition-all ${
                        activeTab === 'chat' ? 'bg-white/10 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'
                    }`}
                >
                    {t('deal.tab_chat')}
                </button>
                <button 
                    onClick={() => setActiveTab('details')}
                    className={`py-2 rounded-lg text-sm font-bold transition-all ${
                        activeTab === 'details' ? 'bg-white/10 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'
                    }`}
                >
                     {t('deal.tab_details')}
                </button>
            </div>
       </div>

       {/* Content */}
       <div className="flex-1 overflow-hidden flex flex-col relative">
           {activeTab === 'chat' ? (
               <>
                   {renderMessages()}
                   
                   {/* Input Bar */}
                   <div className="absolute bottom-0 left-0 right-0 p-4 bg-[#09090b]/90 backdrop-blur-md border-t border-white/10">
                        <div className="flex gap-2 items-end">
                            <input 
                                type="file" 
                                ref={fileInputRef}
                                className="hidden"
                                onChange={handleFileSelect}
                            />
                            <button 
                                onClick={() => fileInputRef.current?.click()}
                                className="p-3 rounded-full bg-white/5 text-gray-400 hover:text-white border border-white/5 hover:bg-white/10 transition-colors"
                            >
                                <Paperclip size={20} />
                            </button>
                            <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl flex items-center">
                                <textarea 
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    placeholder={t('chat.type_message')}
                                    className="w-full bg-transparent px-4 py-3 max-h-24 focus:outline-none resize-none text-sm"
                                    rows={1}
                                    onKeyDown={(e) => {
                                        if(e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSend();
                                        }
                                    }}
                                />
                            </div>
                            <button 
                                onClick={() => handleSend()}
                                disabled={!inputText.trim()}
                                className={`p-3 rounded-full flex items-center justify-center transition-all ${
                                    inputText.trim() 
                                    ? 'bg-neonPurple text-white shadow-[0_0_10px_rgba(139,92,246,0.3)] active:scale-95' 
                                    : 'bg-white/5 text-gray-500'
                                }`}
                            >
                                <Send size={20} />
                            </button>
                        </div>
                   </div>
               </>
           ) : (
               /* Details View */
               <div className="p-4 space-y-6 overflow-y-auto pb-20 animate-fade-in">
                    {deal.status === 'appeal' && (
                        <div className="p-4 rounded-xl bg-orange-500/5 border border-orange-500/20 text-orange-200 text-sm flex gap-3">
                            <Scale className="shrink-0" />
                            <div>{t('deal.appeal_msg')}</div>
                        </div>
                    )}

                    <GlassCard className="space-y-4">
                        <div>
                            <label className="text-xs text-gray-500 uppercase font-semibold">{t('deal.title')}</label>
                            <p className="text-lg font-medium text-white">{deal.title}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs text-gray-500 uppercase font-semibold">{t('deal.amount')}</label>
                                <p className="text-xl font-bold text-white">{deal.price} <span className="text-sm text-neonPurple">{deal.currency}</span></p>
                            </div>
                            <div>
                                <label className="text-xs text-gray-500 uppercase font-semibold">{t('deal.id')}</label>
                                <p className="text-sm font-mono text-gray-400 pt-1">#{deal.id.slice(-6)}</p>
                            </div>
                        </div>
                    </GlassCard>

                    {deal.status === 'active' && (
                        <div className="space-y-3 pt-4">
                            <NeonButton onClick={handleConfirmClick} fullWidth>
                                <ShieldCheck size={18} /> {t('deal.confirm')}
                            </NeonButton>
                            
                            <div className="grid grid-cols-2 gap-3">
                                <NeonButton onClick={() => updateStatus('appeal')} fullWidth className="bg-orange-500/20 border-orange-500/30 text-orange-400 hover:bg-orange-500/30">
                                    <Scale size={18} /> {t('deal.appeal')}
                                </NeonButton>
                                
                                <NeonButton onClick={() => updateStatus('cancelled')} variant="danger" fullWidth>
                                    {t('deal.cancel')}
                                </NeonButton>
                            </div>
                        </div>
                    )}
               </div>
           )}
       </div>
    </div>
  );
};