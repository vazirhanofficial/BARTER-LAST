import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { GlassCard } from '../components/GlassCard';
import { ArrowLeft, Star, ChevronDown, Trophy, History, Medal, Flame } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { User, Deal } from '../types';

interface SellerProfileScreenProps {
  sellerId: number;
  onBack: () => void;
}

type TimeRange = 7 | 30 | 90;

export const SellerProfileScreen: React.FC<SellerProfileScreenProps> = ({ sellerId, onBack }) => {
  const { t } = useLanguage();
  const [seller, setSeller] = useState<User | null>(null);
  const [timeRange, setTimeRange] = useState<TimeRange>(30);
  const [stats, setStats] = useState(0);
  const [deals, setDeals] = useState<Deal[]>([]);

  useEffect(() => {
    const sellerData = storageService.getSellerById(sellerId);
    setSeller(sellerData);
    setStats(storageService.getSellerStats(sellerId, timeRange));
    setDeals(storageService.getSellerDeals(sellerId));
  }, [sellerId, timeRange]);

  if (!seller) return null;

  // Rank Logic
  const getRank = (count: number) => {
    if (count >= 1000) return 'legend';
    if (count >= 500) return 'veteran';
    if (count >= 100) return 'pro';
    return 'novice';
  };

  const rank = getRank(deals.length);

  // Helper to render the specific badge
  const renderRankBadge = () => {
    switch (rank) {
      case 'legend':
        return (
          <div className="relative inline-flex items-center justify-center mt-1 mb-2">
            <div className="phoenix-wing-left"></div>
            <div className="phoenix-wing-right"></div>
            <div className="relative z-10 flex items-center gap-1.5 px-4 py-1 rounded-full border border-orange-500/50 bg-black/60 shadow-[0_0_20px_rgba(239,68,68,0.6)]">
               <Flame size={14} className="text-orange-500 animate-pulse fill-orange-500" />
               <span className="text-[10px] font-black uppercase tracking-wider bg-fire bg-clip-text text-transparent animate-fire-text">
                 {t(`profile.ranks.${rank}`)}
               </span>
               <Flame size={14} className="text-orange-500 animate-pulse fill-orange-500" />
            </div>
          </div>
        );
      case 'veteran':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-slate-400/50 text-[10px] font-black uppercase tracking-wider mb-2 bg-diamond animate-diamond-shine text-white shadow-[0_0_15px_rgba(148,163,184,0.5)]">
             <Star size={12} fill="currentColor" className="text-white" />
             {t(`profile.ranks.${rank}`)}
          </div>
        );
      case 'pro':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-neonBlue text-[10px] font-black uppercase tracking-wider mb-2 bg-neonBlue/10 text-neonBlue animate-neon-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]">
             <Medal size={12} />
             {t(`profile.ranks.${rank}`)}
          </div>
        );
      default: // Novice
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-white/10 text-[10px] font-black uppercase tracking-wider mb-2 bg-white/5 text-gray-400">
             <Medal size={12} />
             {t(`profile.ranks.${rank}`)}
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] flex flex-col relative animate-page-enter">
      {/* Header */}
      <div className="p-4 pt-6 flex items-center gap-4 z-10">
        <button 
          onClick={onBack} 
          className="p-2 -ml-2 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition-colors interactive-bounce"
        >
          <ArrowLeft size={24} />
        </button>
        <h2 className="font-bold text-lg">Profile</h2>
      </div>

      {/* Seller Info */}
      <div className="flex flex-col items-center gap-4 mt-4 px-4">
        <div className="relative group">
          <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-gray-700 to-gray-600 shadow-[0_0_20px_rgba(255,255,255,0.05)]">
            <img 
              src={seller.avatar_url || 'https://picsum.photos/200/200?grayscale'} 
              alt="Profile" 
              className="w-full h-full rounded-full object-cover border-2 border-[#09090b]" 
            />
          </div>
          {/* Status Indicator */}
          <div className={`absolute bottom-1 right-1 w-5 h-5 rounded-full border-[3px] border-[#09090b] ${seller.isOnline ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]' : 'bg-gray-500'}`} />
        </div>

        <div className="text-center w-full flex flex-col items-center">
            <h1 className="text-2xl font-bold tracking-tight text-white mb-1">{seller.username}</h1>
            
            {/* Rank Badge Rendered Here */}
            {renderRankBadge()}

            <div className="flex items-center justify-center gap-3 mt-1">
                 <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${seller.isOnline ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-gray-500/10 text-gray-400 border-gray-500/20'}`}>
                    {seller.isOnline ? t('seller_profile.online') : t('seller_profile.offline')}
                 </span>
                 <div className="flex items-center text-yellow-400 gap-1 bg-yellow-400/10 px-2 py-0.5 rounded-full border border-yellow-400/20">
                     <Star size={12} fill="currentColor" />
                     <span className="text-xs font-bold">{seller.rating}</span>
                 </div>
            </div>
        </div>
      </div>

      {/* Stats Card */}
      <div className="p-4 mt-6">
        <GlassCard className="relative overflow-hidden border-neonBlue/20">
            <div className="flex justify-between items-start mb-2 relative z-10">
                <span className="text-gray-400 text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                    <Trophy size={14} className="text-neonPurple" /> {t('seller_profile.successful_deals')}
                </span>
                <div className="relative">
                    <select
                        value={timeRange}
                        onChange={(e) => setTimeRange(Number(e.target.value) as TimeRange)}
                        className="appearance-none bg-black/40 border border-white/10 rounded-lg py-1.5 pl-3 pr-8 text-xs font-bold focus:outline-none backdrop-blur-md text-neonBlue cursor-pointer hover:bg-black/60 transition-colors"
                    >
                        <option value={7}>{t('seller_profile.period.days_7')}</option>
                        <option value={30}>{t('seller_profile.period.days_30')}</option>
                        <option value={90}>{t('seller_profile.period.days_90')}</option>
                    </select>
                    <ChevronDown size={12} className="absolute right-2 top-2.5 pointer-events-none text-gray-400" />
                </div>
            </div>

            <div className="text-center py-8 relative z-10">
                 <div key={`${sellerId}-${timeRange}`} className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-white/40 animate-pop-in">
                    {stats}
                 </div>
            </div>

            {/* Decorative background */}
            <div className="absolute top-0 right-0 w-40 h-40 bg-neonBlue/10 rounded-full blur-[50px] -mr-10 -mt-10"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-neonPurple/10 rounded-full blur-[50px] -ml-10 -mb-10"></div>
        </GlassCard>
      </div>

      {/* Deal History */}
      <div className="p-4 pt-0 space-y-4 pb-20">
        <div className="flex items-center gap-2 text-gray-300">
          <History size={18} />
          <h3 className="font-semibold">{t('profile.recent_deals')}</h3>
        </div>
        
        <div className="space-y-3">
          {deals.slice(0, 50).map((deal, index) => (
            <GlassCard key={deal.id} className="flex justify-between items-center py-3 animate-slide-up" style={{ animationDelay: `${index * 0.05}s` }}>
              <div>
                <h4 className="font-medium text-sm">{deal.title}</h4>
                <span className={`text-xs px-2 py-0.5 rounded-full inline-block mt-1 ${
                  deal.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                  deal.status === 'cancelled' ? 'bg-red-500/20 text-red-400' :
                  'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {t(`deal.status.${deal.status}`)}
                </span>
              </div>
              <div className="text-right">
                <div className="font-bold text-sm">{deal.price} {deal.currency}</div>
                <div className="text-xs text-gray-500">{new Date(deal.date).toLocaleDateString()}</div>
              </div>
            </GlassCard>
          ))}
          {deals.length === 0 && (
            <div className="text-center text-gray-500 text-sm py-4">{t('profile.no_deals')}</div>
          )}
        </div>
      </div>
    </div>
  );
};