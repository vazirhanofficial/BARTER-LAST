export type Language = 'en' | 'ru';

export const translations = {
  en: {
    nav: {
      search: 'Search',
      chat: 'Chat',
      profile: 'Profile'
    },
    market: {
      title: 'BARTER',
      search: 'Search offers...',
      purchase: 'Purchase',
      no_offers: 'No offers found',
      create: 'Create',
      categories: {
        all: 'All',
        games: 'Games',
        services: 'Services',
        accounts: 'Accounts',
        keys: 'Keys',
        exchange: 'Exchange',
        other: 'Other'
      },
      filters: {
        all: 'ALL',
        title: 'Filters',
        category: 'Category',
        currency: 'Currency',
        sort_by: 'Sort By',
        price_asc: 'Price: Low to High',
        price_desc: 'Price: High to Low',
        rating: 'Seller Rating',
        date: 'Newest First',
        reset: 'Reset'
      }
    },
    create_listing: {
      title: 'New Listing',
      name_placeholder: 'Item Name',
      desc_placeholder: 'Description...',
      price: 'Price',
      income: 'You get ( -10% )',
      publish: 'Publish Listing',
      success: 'Published!'
    },
    chat: {
      title: 'Messages',
      support: 'BARTER Support',
      support_msg: 'How can we help you today?',
      no_messages: 'No messages yet',
      type_message: 'Type a message...',
      header: 'Chat',
      attach_file: 'Attach File'
    },
    profile: {
      balance: 'Total Balance',
      success_rate: 'Success Rate',
      total_deals: 'Total Deals',
      recent_deals: 'Recent Deals',
      no_deals: 'No deals found',
      deposit: 'Deposit',
      withdraw: 'Withdraw',
      settings: 'Settings',
      ranks: {
        novice: 'NOVICE',
        pro: 'PRO',
        veteran: 'VETERAN',
        legend: 'LEGEND'
      }
    },
    seller_profile: {
      online: 'Online',
      offline: 'Offline',
      successful_deals: 'Successful Deals',
      period: {
        days_7: '7 Days',
        days_30: '30 Days',
        days_90: '90 Days'
      }
    },
    deal: {
      tab_chat: 'Chat',
      tab_details: 'Details',
      details: 'Deal Details',
      title: 'Deal Title',
      amount: 'Amount',
      id: 'Deal ID',
      confirm: 'Confirm Receipt',
      cancel: 'Cancel Deal',
      appeal: 'Open Dispute',
      appeal_msg: 'Support team will review this transaction.',
      status: {
        active: 'IN PROCESS',
        completed: 'COMPLETED',
        cancelled: 'CANCELLED',
        appeal: 'DISPUTE OPEN'
      },
      not_found: 'Deal not found'
    },
    settings: {
      title: 'Settings',
      language: 'Language',
      security: 'Security',
      phone: 'Phone Number',
      email: 'Email Address',
      google_auth: 'Google Authenticator',
      verification: 'Identity Verification',
      enabled: 'Enabled',
      enable: 'Enable',
      disable: 'Disable',
      bind: 'Bind',
      change: 'Change',
      saved: 'Saved',
      back: 'Back',
      not_set: 'Not set',
      verified: 'Verified',
      pending: 'Pending',
      rejected: 'Rejected'
    },
    verification: {
      title: 'Identity Verification',
      subtitle: 'Get the trusted seller badge',
      fullname: 'Full Name',
      passport: 'Passport Number',
      selfie: 'Selfie with ID',
      upload: 'Upload / Take Photo',
      submit: 'Submit for Review',
      success: 'You are now verified!',
      processing: 'Verifying data...',
      pending_msg: 'Your documents are under review.'
    },
    payment: {
      deposit_title: 'Add Funds',
      withdraw_title: 'Withdraw Funds',
      card: 'Bank Card',
      card_desc: 'Visa, Mastercard, Mir',
      crypto: 'Cryptocurrency',
      crypto_desc: 'USDT, BTC, ETH, TON',
      enter_amount: 'Enter Amount',
      card_number: 'Card Number',
      expiry: 'MM/YY',
      cvv: 'CVC',
      network: 'Network',
      wallet_address: 'Wallet Address',
      copy: 'Copy',
      copied: 'Copied!',
      confirm: 'Confirm',
      send: 'I have sent',
      processing: 'Processing...',
      success: 'Success!'
    },
    auth: {
      title: 'Security Check',
      enter_code: 'Enter Google Authenticator Code',
      verify: 'Verify',
      invalid: 'Invalid code'
    }
  },
  ru: {
    nav: {
      search: 'Поиск',
      chat: 'Чат',
      profile: 'Профиль'
    },
    market: {
      title: 'BARTER',
      search: 'Поиск объявлений...',
      purchase: 'Купить',
      no_offers: 'Объявлений не найдено',
      create: 'Создать',
      categories: {
        all: 'Все',
        games: 'Игры',
        services: 'Услуги',
        accounts: 'Аккаунты',
        keys: 'Ключи',
        exchange: 'Обмен',
        other: 'Другое'
      },
      filters: {
        all: 'ВСЕ',
        title: 'Фильтры',
        category: 'Категория',
        currency: 'Валюта',
        sort_by: 'Сортировка',
        price_asc: 'Цена: По возрастанию',
        price_desc: 'Цена: По убыванию',
        rating: 'Рейтинг продавца',
        date: 'Сначала новые',
        reset: 'Сбросить'
      }
    },
    create_listing: {
      title: 'Новое объявление',
      name_placeholder: 'Название товара',
      desc_placeholder: 'Описание...',
      price: 'Цена продажи',
      income: 'Вы получите ( -10% )',
      publish: 'Опубликовать',
      success: 'Опубликовано!'
    },
    chat: {
      title: 'Сообщения',
      support: 'Поддержка BARTER',
      support_msg: 'Чем мы можем помочь?',
      no_messages: 'Сообщений пока нет',
      type_message: 'Введите сообщение...',
      header: 'Чат',
      attach_file: 'Прикрепить файл'
    },
    profile: {
      balance: 'Общий баланс',
      success_rate: 'Успешность',
      total_deals: 'Всего сделок',
      recent_deals: 'Недавние сделки',
      no_deals: 'Сделок не найдено',
      deposit: 'Пополнить',
      withdraw: 'Вывести',
      settings: 'Настройки',
      ranks: {
        novice: 'НОВИЧОК',
        pro: 'ПРОФИ',
        veteran: 'ВЕТЕРАН',
        legend: 'ЛЕГЕНДА'
      }
    },
    seller_profile: {
      online: 'Онлайн',
      offline: 'Офлайн',
      successful_deals: 'Успешные сделки',
      period: {
        days_7: '7 дней',
        days_30: '30 дней',
        days_90: '90 дней'
      }
    },
    deal: {
      tab_chat: 'Чат',
      tab_details: 'Детали',
      details: 'Детали сделки',
      title: 'Название',
      amount: 'Сумма',
      id: 'ID сделки',
      confirm: 'Подтвердить',
      cancel: 'Отменить',
      appeal: 'Открыть спор',
      appeal_msg: 'Команда поддержки проверит эту сделку.',
      status: {
        active: 'В ПРОЦЕССЕ',
        completed: 'ЗАВЕРШЕНА',
        cancelled: 'ОТМЕНЕНА',
        appeal: 'АПЕЛЛЯЦИЯ'
      },
      not_found: 'Сделка не найдена'
    },
    settings: {
      title: 'Настройки',
      language: 'Язык',
      security: 'Безопасность',
      phone: 'Номер телефона',
      email: 'Email адрес',
      google_auth: 'Google Authenticator',
      verification: 'Верификация личности',
      enabled: 'Включено',
      enable: 'Включить',
      disable: 'Отключить',
      bind: 'Привязать',
      change: 'Изменить',
      saved: 'Сохранено',
      back: 'Назад',
      not_set: 'Не указан',
      verified: 'Подтвержден',
      pending: 'На проверке',
      rejected: 'Отклонен'
    },
    verification: {
      title: 'Верификация личности',
      subtitle: 'Получите знак надежного продавца',
      fullname: 'ФИО (по паспорту)',
      passport: 'Серия и номер паспорта',
      selfie: 'Селфи с паспортом',
      upload: 'Загрузить / Сделать фото',
      submit: 'Отправить на проверку',
      success: 'Вы успешно верифицированы!',
      processing: 'Проверка данных...',
      pending_msg: 'Ваши документы находятся на проверке.'
    },
    payment: {
      deposit_title: 'Пополнение',
      withdraw_title: 'Вывод средств',
      card: 'Банковская карта',
      card_desc: 'Visa, Mastercard, Mir',
      crypto: 'Криптовалюта',
      crypto_desc: 'USDT, BTC, ETH, TON',
      enter_amount: 'Введите сумму',
      card_number: 'Номер карты',
      expiry: 'ММ/ГГ',
      cvv: 'CVC',
      network: 'Сеть',
      wallet_address: 'Адрес кошелька',
      copy: 'Копировать',
      copied: 'Скопировано!',
      confirm: 'Подтвердить',
      send: 'Я отправил',
      processing: 'Обработка...',
      success: 'Успешно!'
    },
    auth: {
      title: 'Проверка безопасности',
      enter_code: 'Введите код Google Authenticator',
      verify: 'Подтвердить',
      invalid: 'Неверный код'
    }
  }
};