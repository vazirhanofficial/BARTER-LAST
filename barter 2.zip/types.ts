export type Currency = 'RUB' | 'USD' | 'EUR' | 'USDT' | 'BTC' | 'ETH' | 'SOL';

export interface User {
  id: number;
  username: string;
  avatar_url?: string;
  rating: number; // 0-5
  phone?: string;
  email?: string;
  isOnline?: boolean; // Added for seller profile
  googleAuthEnabled?: boolean; // Added for security settings
  isProfileModified?: boolean; // Flag to prevent Telegram sync overwrite
  verificationStatus: 'none' | 'pending' | 'verified' | 'rejected'; // Added verification
}

export interface Product {
  id: string;
  sellerId: number;
  sellerName: string;
  sellerAvatar?: string;
  sellerRating: number;
  title: string;
  description: string;
  price: number;
  currency: Currency;
  category: string;
  date: string; // ISO String
}

export interface Deal {
  id: string;
  productId: string;
  sellerId: number;
  buyerId: number;
  title: string;
  price: number;
  currency: Currency;
  status: 'active' | 'completed' | 'cancelled' | 'appeal';
  date: string; // ISO string
}

export interface Attachment {
  id: string;
  type: 'image' | 'file';
  url: string;
  name: string;
  size?: string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: number;
  text: string;
  attachments?: Attachment[];
  timestamp: string;
  status?: 'sent' | 'read'; // Added status
}

export interface ChatPreview {
  id: string;
  partnerId: number;
  partnerName: string;
  partnerAvatar?: string;
  lastMessage: string;
  unreadCount: number;
  timestamp: string;
}

export enum AppScreen {
  MARKET = 'MARKET',
  CHAT_LIST = 'CHAT_LIST',
  CHAT_DETAIL = 'CHAT_DETAIL',
  PROFILE = 'PROFILE',
  DEAL_DETAIL = 'DEAL_DETAIL',
  SELLER_PROFILE = 'SELLER_PROFILE',
}