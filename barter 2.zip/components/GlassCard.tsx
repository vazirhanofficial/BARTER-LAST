import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className = '', onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={`glass-card rounded-2xl p-4 transition-all duration-300 ease-out ${className} ${
        onClick ? 'cursor-pointer active:scale-[0.98] active:opacity-90 hover:bg-white/[0.07]' : ''
      }`}
    >
      {children}
    </div>
  );
};