import React, { useState, useEffect, useRef } from 'react';
import { GlassCard } from './GlassCard';
import { NeonButton } from './NeonButton';
import { Shield, X, Lock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface GoogleAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerify: (code: string) => void;
}

export const GoogleAuthModal: React.FC<GoogleAuthModalProps> = ({ isOpen, onClose, onVerify }) => {
  const { t } = useLanguage();
  const [code, setCode] = useState('');
  const [error, setError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setCode('');
      setError(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (code.length === 6) {
      onVerify(code);
    } else {
      setError(true);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-md animate-fade-in"
        onClick={onClose}
      />
      
      <GlassCard className="relative w-full max-w-sm p-6 animate-pop-in bg-[#09090b]/95 border-neonPurple/30">
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-400 hover:text-white"
        >
          <X size={20} />
        </button>

        <div className="flex flex-col items-center gap-4 text-center">
          <div className="w-16 h-16 rounded-full bg-neonPurple/10 flex items-center justify-center text-neonPurple border border-neonPurple/20 shadow-[0_0_20px_rgba(139,92,246,0.2)]">
            <Shield size={32} />
          </div>

          <div>
            <h3 className="text-xl font-bold text-white mb-1">{t('auth.title')}</h3>
            <p className="text-sm text-gray-400">{t('auth.enter_code')}</p>
          </div>

          <form onSubmit={handleSubmit} className="w-full space-y-4 mt-2">
            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                value={code}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 6);
                  setCode(val);
                  setError(false);
                  if(val.length === 6) {
                      // Optionally auto-submit or just let user click
                  }
                }}
                className={`w-full bg-black/40 border ${error ? 'border-red-500 text-red-400' : 'border-white/10 text-white'} rounded-xl py-4 text-center text-2xl font-mono tracking-[0.5em] focus:outline-none focus:border-neonPurple transition-colors`}
                placeholder="000000"
                maxLength={6}
                inputMode="numeric"
              />
              <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            </div>

            {error && (
              <p className="text-xs text-red-500 animate-pulse">{t('auth.invalid')}</p>
            )}

            <NeonButton 
              type="submit" 
              fullWidth 
              disabled={code.length !== 6}
              className={code.length !== 6 ? 'opacity-50' : ''}
            >
              {t('auth.verify')}
            </NeonButton>
          </form>
        </div>
      </GlassCard>
    </div>
  );
};