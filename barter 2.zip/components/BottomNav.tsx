import React from 'react';
import { AppScreen } from '../types';
import { Search, MessageSquare, User } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface BottomNavProps {
  activeTab: AppScreen;
  onTabChange: (tab: AppScreen) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const { t } = useLanguage();

  const tabs = [
    { id: AppScreen.MARKET, icon: Search, label: t('nav.search') },
    { id: AppScreen.CHAT_LIST, icon: MessageSquare, label: t('nav.chat') },
    { id: AppScreen.PROFILE, icon: User, label: t('nav.profile') },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 pointer-events-none">
      {/* Gradient Mask to hide scrolling content below and behind the bar */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#09090b] via-[#09090b]/95 to-transparent" />

      {/* Nav Container - Positioned slightly lower (pb-5) */}
      <div className="relative p-4 pb-5 flex justify-center">
        <div className="glass-nav rounded-full px-2 py-2 flex justify-between items-center w-full max-w-md pointer-events-auto shadow-[0_-10px_40px_rgba(0,0,0,0.5)] backdrop-blur-2xl">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`relative flex items-center justify-center gap-2 px-6 py-3 rounded-full transition-all duration-300 ${
                  isActive 
                    ? 'flex-1 bg-white/10 text-white shadow-[0_0_15px_rgba(139,92,246,0.3)]' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Icon 
                  size={isActive ? 22 : 24} 
                  className={`transition-all duration-300 ${isActive ? 'text-neonPurple' : ''}`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                {isActive && (
                  <span className="text-sm font-semibold animate-fade-in whitespace-nowrap">
                    {tab.label}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};