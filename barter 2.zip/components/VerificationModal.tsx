import React, { useState, useRef } from 'react';
import { GlassCard } from './GlassCard';
import { NeonButton } from './NeonButton';
import { BadgeCheck, X, Camera, FileText, User as UserIcon, Upload } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerify: (data: { fullname: string; passport: string; selfie: string }) => void;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({ isOpen, onClose, onVerify }) => {
  const { t } = useLanguage();
  const [fullname, setFullname] = useState('');
  const [passport, setPassport] = useState('');
  const [selfie, setSelfie] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelfie(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!fullname || !passport || !selfie) return;
    
    setLoading(true);
    // Simulate verification delay
    setTimeout(() => {
        setLoading(false);
        onVerify({ fullname, passport, selfie });
    }, 2000);
  };

  const isFormValid = fullname.length > 3 && passport.length > 5 && selfie;

  return (
    <div className="fixed inset-0 z-[150] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-md animate-fade-in"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-md animate-slide-up">
        <GlassCard className="bg-[#09090b] border-t border-neonBlue/30 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] rounded-b-none sm:rounded-2xl max-h-[90vh] overflow-y-auto">
          <button 
            onClick={onClose}
            className="absolute right-4 top-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white z-10"
          >
            <X size={20} />
          </button>

          <div className="flex flex-col items-center gap-4 text-center mb-6 pt-2">
            <div className="w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20 shadow-[0_0_20px_rgba(59,130,246,0.2)]">
              <BadgeCheck size={32} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white mb-1">{t('verification.title')}</h3>
              <p className="text-sm text-gray-400">{t('verification.subtitle')}</p>
            </div>
          </div>

          {!loading ? (
             <div className="space-y-4">
                {/* Full Name */}
                <div className="space-y-1.5">
                    <label className="text-xs text-gray-400 ml-1 flex items-center gap-1">
                        <UserIcon size={12} /> {t('verification.fullname')}
                    </label>
                    <input
                        type="text"
                        value={fullname}
                        onChange={(e) => setFullname(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-3 focus:border-blue-500 focus:outline-none transition-colors"
                        placeholder="John Doe"
                    />
                </div>

                {/* Passport */}
                <div className="space-y-1.5">
                    <label className="text-xs text-gray-400 ml-1 flex items-center gap-1">
                        <FileText size={12} /> {t('verification.passport')}
                    </label>
                    <input
                        type="text"
                        value={passport}
                        onChange={(e) => setPassport(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-3 focus:border-blue-500 focus:outline-none transition-colors"
                        placeholder="1234 567890"
                    />
                </div>

                {/* Selfie Upload */}
                <div className="space-y-1.5">
                    <label className="text-xs text-gray-400 ml-1 flex items-center gap-1">
                        <Camera size={12} /> {t('verification.selfie')}
                    </label>
                    <div 
                        onClick={() => fileInputRef.current?.click()}
                        className={`w-full h-40 border-2 border-dashed rounded-xl flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden relative ${
                            selfie ? 'border-blue-500/50' : 'border-white/10 hover:border-white/30 hover:bg-white/5'
                        }`}
                    >
                        {selfie ? (
                            <>
                                <img src={selfie} alt="Selfie" className="absolute inset-0 w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                                    <Camera size={24} className="text-white" />
                                </div>
                            </>
                        ) : (
                            <>
                                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-2">
                                    <Upload size={20} className="text-gray-400" />
                                </div>
                                <span className="text-sm text-gray-400">{t('verification.upload')}</span>
                            </>
                        )}
                        <input 
                            type="file" 
                            ref={fileInputRef} 
                            className="hidden" 
                            accept="image/*" 
                            capture="user"
                            onChange={handleFileChange}
                        />
                    </div>
                </div>

                <div className="pt-2">
                    <NeonButton 
                        onClick={handleSubmit} 
                        fullWidth 
                        disabled={!isFormValid}
                        className={!isFormValid ? 'opacity-50 grayscale' : 'bg-gradient-to-r from-blue-600 to-cyan-600 border-blue-400/30'}
                    >
                        {t('verification.submit')}
                    </NeonButton>
                </div>
             </div>
          ) : (
             <div className="flex flex-col items-center justify-center py-12 space-y-6 animate-fade-in">
                <div className="relative">
                    <div className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <ShieldCheckIcon className="text-blue-500 animate-pulse" size={24} />
                    </div>
                </div>
                <div className="text-center">
                    <h3 className="text-lg font-bold text-white mb-1">{t('verification.processing')}</h3>
                    <p className="text-xs text-gray-500">Connecting to secure servers...</p>
                </div>
             </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
};

const ShieldCheckIcon = ({ className, size }: { className?: string; size?: number }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
);