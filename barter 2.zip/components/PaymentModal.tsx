import React, { useState, useEffect } from 'react';
import { GlassCard } from './GlassCard';
import { CreditCard, Wallet, X, ChevronLeft, Copy, Check, Lock, Smartphone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { NeonButton } from './NeonButton';
import { Currency } from '../types';

interface PaymentModalProps {
  isOpen: boolean;
  type: 'deposit' | 'withdraw' | null;
  onClose: () => void;
  onConfirm: (amount: number, currency: Currency) => void;
}

type Step = 'menu' | 'card_form' | 'crypto_form' | 'processing' | 'success';

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, type, onClose, onConfirm }) => {
  const { t } = useLanguage();
  
  // Navigation State
  const [step, setStep] = useState<Step>('menu');
  
  // Form State
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<Currency>('USD');
  
  // Card Specific
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  
  // Crypto Specific
  const [network, setNetwork] = useState('TRC20');
  const [walletAddr, setWalletAddr] = useState('');
  const [copied, setCopied] = useState(false);

  // Mock Deposit Address
  const DEPOSIT_ADDRESS = "TM1zdP481...7xX9L"; 

  // Reset when opening
  useEffect(() => {
    if (isOpen) {
      setStep('menu');
      setAmount('');
      setCardNumber('');
      setExpiry('');
      setCvc('');
      setWalletAddr('');
    }
  }, [isOpen]);

  const handleCopy = () => {
    navigator.clipboard.writeText(DEPOSIT_ADDRESS);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const processPayment = () => {
    if (!amount) return;
    setStep('processing');
    setTimeout(() => {
      setStep('success');
      setTimeout(() => {
        onConfirm(parseFloat(amount), currency);
        onClose();
      }, 1000);
    }, 1500);
  };

  if (!isOpen || !type) return null;

  const renderHeader = () => (
    <div className="flex justify-between items-center mb-6">
       <div className="flex items-center gap-2">
         {step !== 'menu' && step !== 'processing' && step !== 'success' && (
           <button onClick={() => setStep('menu')} className="p-1 -ml-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white">
             <ChevronLeft size={24} />
           </button>
         )}
         <h2 className="text-xl font-bold">
            {type === 'deposit' ? t('payment.deposit_title') : t('payment.withdraw_title')}
         </h2>
       </div>
       <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 text-gray-400 hover:text-white">
         <X size={20} />
       </button>
    </div>
  );

  const renderMenu = () => (
    <div className="space-y-3 animate-slide-up">
      <button 
        onClick={() => setStep('card_form')}
        className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-neonPurple/50 transition-all group"
      >
        <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
          <CreditCard size={24} />
        </div>
        <div className="text-left">
          <div className="font-bold text-white">{t('payment.card')}</div>
          <div className="text-xs text-gray-400">{t('payment.card_desc')}</div>
        </div>
      </button>

      <button 
        onClick={() => setStep('crypto_form')}
        className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-neonPurple/50 transition-all group"
      >
        <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 group-hover:scale-110 transition-transform">
          <Wallet size={24} />
        </div>
        <div className="text-left">
          <div className="font-bold text-white">{t('payment.crypto')}</div>
          <div className="text-xs text-gray-400">{t('payment.crypto_desc')}</div>
        </div>
      </button>
    </div>
  );

  const renderCardForm = () => (
    <div className="space-y-4 animate-slide-up">
      {/* Amount Input */}
      <div>
        <label className="text-xs text-gray-500 ml-1">{t('payment.enter_amount')}</label>
        <div className="relative">
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-lg font-bold focus:border-neonPurple focus:outline-none"
            placeholder="0.00"
            autoFocus
          />
          <div className="absolute right-2 top-2 bottom-2">
            <select 
              value={currency}
              onChange={(e) => setCurrency(e.target.value as Currency)}
              className="h-full bg-transparent text-sm font-bold text-gray-300 focus:outline-none"
            >
               {['USD', 'RUB', 'EUR'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Card Details */}
      <div className="space-y-3">
         <div>
            <label className="text-xs text-gray-500 ml-1">{t('payment.card_number')}</label>
            <div className="relative">
                <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 pl-10 tracking-wider focus:border-neonBlue focus:outline-none"
                    placeholder="0000 0000 0000 0000"
                />
                <CreditCard size={18} className="absolute left-3 top-3.5 text-gray-500" />
            </div>
         </div>
         <div className="grid grid-cols-2 gap-3">
             <div>
                <label className="text-xs text-gray-500 ml-1">{t('payment.expiry')}</label>
                <input
                    type="text"
                    value={expiry}
                    onChange={(e) => setExpiry(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-center focus:border-neonBlue focus:outline-none"
                    placeholder="MM/YY"
                />
             </div>
             <div>
                <label className="text-xs text-gray-500 ml-1">{t('payment.cvv')}</label>
                <div className="relative">
                    <input
                        type="password"
                        value={cvc}
                        onChange={(e) => setCvc(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-center focus:border-neonBlue focus:outline-none"
                        placeholder="•••"
                        maxLength={3}
                    />
                    <Lock size={14} className="absolute right-3 top-3.5 text-gray-500" />
                </div>
             </div>
         </div>
      </div>

      <NeonButton onClick={processPayment} fullWidth className="mt-2">
         {t('payment.confirm')}
      </NeonButton>
    </div>
  );

  const renderCryptoForm = () => (
    <div className="space-y-4 animate-slide-up">
      {/* Network Selection */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-lg">
         {['TRC20', 'ERC20', 'BTC', 'TON'].map(net => (
             <button
                key={net}
                onClick={() => setNetwork(net)}
                className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
                    network === net ? 'bg-neonPurple text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'
                }`}
             >
                 {net}
             </button>
         ))}
      </div>

      {/* Amount Input */}
      <div>
        <label className="text-xs text-gray-500 ml-1">{t('payment.enter_amount')}</label>
        <div className="relative">
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-lg font-bold focus:border-neonPurple focus:outline-none"
            placeholder="0.00"
          />
          <div className="absolute right-2 top-2 bottom-2 flex items-center">
             <span className="text-sm font-bold text-gray-300 pr-2">USDT</span>
          </div>
        </div>
      </div>

      {type === 'deposit' ? (
          /* Deposit View (QR) */
          <div className="flex flex-col items-center gap-4 py-2">
             <div className="p-2 bg-white rounded-xl">
                {/* Simulated QR Code */}
                <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${DEPOSIT_ADDRESS}`} 
                    alt="QR" 
                    className="w-32 h-32 opacity-90"
                />
             </div>
             
             <div className="w-full">
                <label className="text-xs text-gray-500 ml-1">{t('payment.wallet_address')}</label>
                <div 
                    onClick={handleCopy}
                    className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl p-3 cursor-pointer hover:bg-white/10 active:scale-[0.98] transition-all"
                >
                    <span className="text-xs font-mono text-gray-300 truncate mr-2">{DEPOSIT_ADDRESS}</span>
                    {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} className="text-gray-500" />}
                </div>
             </div>

             <NeonButton onClick={processPayment} fullWidth>
                {t('payment.send')}
             </NeonButton>
          </div>
      ) : (
          /* Withdraw View (Input Address) */
          <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 ml-1">{t('payment.wallet_address')}</label>
                <input
                    type="text"
                    value={walletAddr}
                    onChange={(e) => setWalletAddr(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm font-mono focus:border-neonPurple focus:outline-none"
                    placeholder="T..."
                />
              </div>
              <NeonButton onClick={processPayment} fullWidth>
                {t('payment.confirm')}
             </NeonButton>
          </div>
      )}
    </div>
  );

  const renderProcessing = () => (
      <div className="flex flex-col items-center justify-center py-12 space-y-4 animate-fade-in">
          <div className="w-12 h-12 border-4 border-neonPurple border-t-transparent rounded-full animate-spin"></div>
          <span className="text-gray-400 font-medium animate-pulse">{t('payment.processing')}</span>
      </div>
  );

  const renderSuccess = () => (
      <div className="flex flex-col items-center justify-center py-12 space-y-4 animate-pop-in">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center text-green-400 border border-green-500/30 shadow-[0_0_20px_rgba(34,197,94,0.3)]">
              <Check size={32} />
          </div>
          <span className="text-white font-bold text-lg">{t('payment.success')}</span>
      </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      ></div>

      <div className="relative w-full max-w-md p-4">
        <GlassCard className="bg-[#09090b]/95 border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] overflow-hidden min-h-[350px]">
          {renderHeader()}

          {step === 'menu' && renderMenu()}
          {step === 'card_form' && renderCardForm()}
          {step === 'crypto_form' && renderCryptoForm()}
          {step === 'processing' && renderProcessing()}
          {step === 'success' && renderSuccess()}
          
        </GlassCard>
      </div>
    </div>
  );
};