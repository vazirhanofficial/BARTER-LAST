import React, { useEffect, useState } from 'react';
import { ArrowRightLeft } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [shouldRender, setShouldRender] = useState(true);

  useEffect(() => {
    // Start exit animation after 2.5s
    const timer = setTimeout(() => {
      setIsVisible(false);
      // Unmount after exit animation
      setTimeout(() => {
        setShouldRender(false);
        onComplete();
      }, 700);
    }, 2500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!shouldRender) return null;

  return (
    <div 
      className={`fixed inset-0 z-[200] flex flex-col items-center justify-center bg-[#09090b] transition-opacity duration-700 ease-out ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
    >
      <div className="relative">
        <div className="flex items-center gap-6 animate-clean-reveal">
           {/* Main Logo Text */}
          <h1 className="text-5xl font-black tracking-[0.25em] text-white select-none">
            BARTER
          </h1>
          {/* Animated Icon */}
          <ArrowRightLeft size={42} className="text-neonPurple animate-exchange-rotate" />
        </div>
        
        {/* Subtle decorative glow behind */}
        <div className="absolute inset-0 bg-neonPurple/20 blur-[40px] rounded-full animate-pulse" />
      </div>
      
      <p className="mt-4 text-xs text-gray-500 font-medium tracking-widest uppercase opacity-0 animate-[fadeIn_1s_ease-out_0.5s_forwards]">
        Premium Digital Market
      </p>
    </div>
  );
};