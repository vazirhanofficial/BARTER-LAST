import { Product, Deal, Message, ChatPreview, User } from '../types';

const KEYS = {
  PRODUCTS: 'barter_products',
  DEALS: 'barter_deals',
  CHATS: 'barter_chats',
  MESSAGES: 'barter_messages',
  USER: 'barter_user_settings',
};

// Mock Data Seeding
const MOCK_PRODUCTS: Product[] = [
  {
    id: 'p1',
    sellerId: 999, // Will be LEGEND
    sellerName: 'Legendary_Seller',
    sellerRating: 5.0,
    title: 'Level 80 Paladin | Rare Mounts',
    description: 'Selling my main account, original owner. Includes spectral tiger.',
    price: 150,
    currency: 'USD',
    category: 'Games',
    sellerAvatar: 'https://picsum.photos/100/100?random=1',
    date: new Date(Date.now() - 10000000).toISOString()
  },
  {
    id: 'p2',
    sellerId: 888, // Will be VETERAN
    sellerName: 'Veteran_Trader',
    sellerRating: 4.9,
    title: '1000 USDT Exchange',
    description: 'Fast exchange to RUB cards. verified merchant.',
    price: 98000,
    currency: 'RUB',
    category: 'Exchange',
    sellerAvatar: 'https://picsum.photos/100/100?random=2',
    date: new Date(Date.now() - 5000000).toISOString()
  },
  {
    id: 'p3',
    sellerId: 777, // Will be PRO
    sellerName: 'Pro_Service_X',
    sellerRating: 4.7,
    title: 'Premium Logo Design',
    description: 'Professional vector logo with 3 revisions.',
    price: 50,
    currency: 'USDT',
    category: 'Services',
    sellerAvatar: 'https://picsum.photos/100/100?random=3',
    date: new Date(Date.now() - 200000).toISOString()
  },
  {
    id: 'p4',
    sellerId: 666, // Will be NOVICE
    sellerName: 'Newbie_Store',
    sellerRating: 4.2,
    title: 'Elden Ring Key (Global)',
    description: 'Instant delivery after payment.',
    price: 0.0015,
    currency: 'BTC',
    category: 'Keys',
    sellerAvatar: 'https://picsum.photos/100/100?random=4',
    date: new Date().toISOString()
  }
];

const DEFAULT_USER: User = {
  id: 100,
  username: 'Trader_One',
  avatar_url: 'https://picsum.photos/200/200?grayscale',
  rating: 4.8,
  phone: undefined,
  email: undefined,
  googleAuthEnabled: true, 
  isProfileModified: false,
  verificationStatus: 'none',
  // @ts-ignore - Adding balance to mock user which isn't in interface but used in profile
  balance: {
    USD: 1240.50,
    RUB: 85000,
    USDT: 450.00,
    BTC: 0.045,
    ETH: 1.2,
    EUR: 0,
    SOL: 15.5
  }
};

export const storageService = {
  getUser: () => {
    const data = localStorage.getItem(KEYS.USER);
    if (!data) {
      localStorage.setItem(KEYS.USER, JSON.stringify(DEFAULT_USER));
      return DEFAULT_USER;
    }
    const user = JSON.parse(data);
    // Ensure new fields exist for old data
    if (!user.verificationStatus) user.verificationStatus = 'none';
    return user;
  },

  saveUser: (user: any) => {
    localStorage.setItem(KEYS.USER, JSON.stringify(user));
  },

  // Sync with Telegram User Data
  syncWithTelegram: (tgUser: any) => {
    if (!tgUser) return;
    
    const currentUser = storageService.getUser();
    let updatedUser = { ...currentUser };
    let hasChanges = false;

    // Case 1: First time sync (replacing default mock user) or replacing a different user
    if (currentUser.id === 100) {
      updatedUser.id = tgUser.id;
      // Only set these if we haven't manually modified them in the mock phase (unlikely but safe)
      if (!currentUser.isProfileModified) {
          updatedUser.username = tgUser.username || tgUser.first_name || 'User';
          if (tgUser.photo_url) {
              updatedUser.avatar_url = tgUser.photo_url;
          }
      }
      hasChanges = true;
    } 
    // Case 2: Existing user returning, check if we need to update info
    else if (currentUser.id === tgUser.id) {
        if (!currentUser.isProfileModified) {
            const newName = tgUser.username || tgUser.first_name;
            if (newName && currentUser.username !== newName) {
                updatedUser.username = newName;
                hasChanges = true;
            }
            if (tgUser.photo_url && currentUser.avatar_url !== tgUser.photo_url) {
                updatedUser.avatar_url = tgUser.photo_url;
                hasChanges = true;
            }
        }
    }

    if (hasChanges) {
        storageService.saveUser(updatedUser);
    }
  },

  // Mock function to get another user/seller profile
  getSellerById: (id: number): User => {
    // Current User
    const currentUser = storageService.getUser();
    if (id === currentUser.id) return currentUser;

    // Try to find in mock products first
    const product = MOCK_PRODUCTS.find(p => p.sellerId === id);
    if (product) {
        return {
            id: product.sellerId,
            username: product.sellerName,
            rating: product.sellerRating,
            avatar_url: product.sellerAvatar,
            isOnline: Math.random() > 0.3, // Mock online status
            verificationStatus: 'verified' // Mock verified status for top sellers
        };
    }
    return {
        id,
        username: `Seller_${id}`,
        rating: 0,
        avatar_url: 'https://picsum.photos/200/200?grayscale',
        isOnline: false,
        verificationStatus: 'none'
    };
  },

  getSellerStats: (id: number, days: number): number => {
    const currentUser = storageService.getUser();
    // For Current User (Legend), return high stats
    if (id === currentUser.id) {
        return days === 7 ? 45 : days === 30 ? 210 : 1050; 
    }

    // Generate a deterministic but pseudo-random number based on ID and days
    const base = (id % 100) + 20;
    const multiplier = days === 7 ? 0.2 : days === 30 ? 0.5 : 1.2;
    return Math.floor(base * multiplier);
  },

  getSellerDeals: (sellerId: number): Deal[] => {
    // 1. Get real deals from storage where this user is the seller
    const allDeals: Deal[] = storageService.getDeals();
    const realDeals = allDeals.filter(d => d.sellerId === sellerId);
    
    const currentUser = storageService.getUser();

    // 2. Generate mock history based on Seller ID to guarantee ranks
    let mockCount = 0;
    if (sellerId === 999) mockCount = 1200; // Legend
    else if (sellerId === 888) mockCount = 600; // Veteran
    else if (sellerId === 777) mockCount = 150; // Pro
    else if (sellerId === currentUser.id) return realDeals; // Current user handled separately
    else mockCount = (sellerId % 5) + 3; // Novice

    const mockDeals: Deal[] = Array.from({ length: mockCount }).map((_, i) => ({
      id: `mock_${sellerId}_${i}`,
      productId: `mock_p_${sellerId}_${i}`,
      sellerId: sellerId,
      buyerId: 999,
      title: ['Premium Account', 'Gold Currency', 'Rare Skin', 'Boosting Service', 'Game Key'][i % 5],
      price: (i + 1) * 150,
      currency: 'USD',
      status: 'completed',
      date: new Date(Date.now() - (i * 100000000) - 86400000).toISOString()
    }));

    // If it's the current user, we mostly rely on real deals (which include the generated legend deals)
    if (sellerId === currentUser.id) {
        return realDeals.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }

    return [...realDeals, ...mockDeals].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  },

  getProducts: (): Product[] => {
    const data = localStorage.getItem(KEYS.PRODUCTS);
    if (!data) {
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(MOCK_PRODUCTS));
      return MOCK_PRODUCTS;
    }
    return JSON.parse(data);
  },

  saveProduct: (product: Product) => {
    const products = storageService.getProducts();
    products.unshift(product);
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  },

  getDeals: (): Deal[] => {
    const data = localStorage.getItem(KEYS.DEALS);
    let deals: Deal[] = data ? JSON.parse(data) : [];
    const currentUser = storageService.getUser();

    // --- LEGEND RANK INJECTION ---
    // Ensure current user has enough deals to be a Legend (> 1000) for demo purposes
    // We use the Dynamic Current User ID
    const userDealsCount = deals.filter(d => d.sellerId === currentUser.id || d.buyerId === currentUser.id).length;
    
    if (userDealsCount < 1005) {
        const missing = 1005 - userDealsCount;
        const legendDeals: Deal[] = Array.from({ length: missing }).map((_, i) => ({
            id: `legend_auto_${Date.now()}_${i}`,
            productId: `p_leg_${i}`,
            sellerId: currentUser.id,
            buyerId: 999,
            title: i % 2 === 0 ? 'Fast Exchange USDT' : 'Game Account Sale',
            price: 50 + (i % 50),
            currency: 'USDT',
            status: 'completed',
            // Spread dates over the last year
            date: new Date(Date.now() - (i * 3600000 * 2)).toISOString() 
        }));
        
        deals = [...deals, ...legendDeals];
        // Save automatically so it persists
        localStorage.setItem(KEYS.DEALS, JSON.stringify(deals));
    }
    // -----------------------------

    return deals;
  },

  saveDeal: (deal: Deal) => {
    const deals = storageService.getDeals();
    // Update if exists, else add
    const index = deals.findIndex(d => d.id === deal.id);
    if (index >= 0) {
      deals[index] = deal;
    } else {
      deals.unshift(deal);
    }
    localStorage.setItem(KEYS.DEALS, JSON.stringify(deals));
  },

  getChats: (): ChatPreview[] => {
    const data = localStorage.getItem(KEYS.CHATS);
    return data ? JSON.parse(data) : [];
  },

  saveChat: (chat: ChatPreview) => {
    const chats = storageService.getChats();
    const index = chats.findIndex(c => c.id === chat.id);
    if (index >= 0) {
      chats[index] = chat;
    } else {
      chats.unshift(chat);
    }
    localStorage.setItem(KEYS.CHATS, JSON.stringify(chats));
  },

  getMessages: (chatId: string): Message[] => {
    const allMessages: Record<string, Message[]> = JSON.parse(localStorage.getItem(KEYS.MESSAGES) || '{}');
    return allMessages[chatId] || [];
  },

  saveMessage: (message: Message) => {
    const allMessages: Record<string, Message[]> = JSON.parse(localStorage.getItem(KEYS.MESSAGES) || '{}');
    if (!allMessages[message.chatId]) {
      allMessages[message.chatId] = [];
    }
    allMessages[message.chatId].push(message);
    localStorage.setItem(KEYS.MESSAGES, JSON.stringify(allMessages));
  },
  
  markAllAsRead: (chatId: string) => {
     const allMessages: Record<string, Message[]> = JSON.parse(localStorage.getItem(KEYS.MESSAGES) || '{}');
     if (allMessages[chatId]) {
         allMessages[chatId] = allMessages[chatId].map(m => ({...m, status: 'read'}));
         localStorage.setItem(KEYS.MESSAGES, JSON.stringify(allMessages));
     }
  }
};